APP.controller('UTTCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');

	$scope.title="Gestion de utilisateurs";
	$scope.tmp="";

/************************************
 * 
 * modal function
 * 
 * */
	$scope.AddUser=function(){
		$scope.addmodalInstance =$modal.open({
			templateUrl:"newuserModal.html",
			scope: $scope,
		});
	};

	$scope.cancel = function () {
		$scope.tmp="";
		$scope.addmodalInstance.dismiss('cancel');
	};

	$scope.addUserBase=function(username,pwd1,pwd2,selectedCompte){
		if(pwd1!=pwd2){
			alert("pwd not equal");
		}
		else{
			$http.post('/compte/add_user',{username:username,pwd:pwd1,compte_id:selectedCompte}).success(function(data) {
				$scope.utilisateurs.push(data);
				$scope.addmodalInstance.dismiss('cancel');				
			});			

		}
	};

/************************************
 * 
 * 
 * */	

	$scope.confirm = function(user_id){
		$scope.tmp=user_id;
		$scope.addmodalInstance =$modal.open({
			templateUrl:"confirmModal.html",
			scope: $scope,
		});		
	};

	$scope.deleteThis = function(user_id){
		
		$http.post('/compte/delete_user',{user_id:user_id}).success(function(data) {
			$scope.utilisateurs=_.reject($scope.utilisateurs, function(obj){ return obj._id == user_id; });
			$scope.addmodalInstance.dismiss('cancel');				
		});		
	};
 
 /************************************
 * 
 * 
 * */
	$http.post('/compte/all_user').success(function(data) {
		$scope.utilisateurs=data;
		$scope.num_total=data.length;
		
	});
	
	$http.post('/compte/all_compte').success(function(data) {
		$scope.comptes=data;
	});	

}]);
