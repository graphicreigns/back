APP.controller('ReGeCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');

	$scope.title1="Régénérer le tableaux de Statistique Aqualung";
	$scope.title2="Re-enovyer les deux mails";	
	$scope.last_time="";


	$scope.do_regenerer=function(){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html",
			size: 'sm'			
		});	
		
		$http.post('/action/regenerer').success(function(data){
			$scope.last_time=new Date().toLocaleString();
			alert(data);
			waitmodalInstance.close();

		});		
	};

	$scope.do_reenvoyer=function(){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html",
			size: 'sm'			
		});	
		
		$http.post('/action/reenvoyer').success(function(data){
			alert(data);
			waitmodalInstance.close();

		});		
	};


	
	$http.post('/gestion/sta_aqu').success(function(data){
		if(data.last_time!="error"){
			$scope.last_time=new Date(data.last_time).toLocaleString();
		}
		else{
			$scope.last_time="no data";
		}
	});
	
	
	
	
	
}]);
