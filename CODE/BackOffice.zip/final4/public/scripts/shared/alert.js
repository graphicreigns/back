APP.controller('AlertCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');

	$scope.title="Gestion de Panneau Alert";
	$scope.compte="aqualung";

	$scope.proxy_addr="(no proxy)";
	$scope.proxy_type="http";
	$scope.ips_save=[];
		
	$scope.refresh_mag_sel=2;

	$scope.data=[];
	$scope.num_show=0;

	$scope.flag_roue=true;
	
	$scope.status=false;	
	$scope.exec_flag=true;
	$scope.array_refresh=[];
	$scope.exec_num_fail=0;
	
	$scope.do_change = function(){
		
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html",
			size: 'sm'			
		});	
		
		$http.post('/compte/sites',{"site_name":$scope.compte}).success(function(data){
			$scope.sites = data;
		}); 
		
		$http.post('/gestion/alert',{"user_name":$scope.compte}).success(function(data) {
			waitmodalInstance.close();
			$scope.data=data;
			$scope.num_show=data.length;

		});

	}
	
	$scope.do_refresh = function(){
		
		$scope.status=true;
		
		$scope.array_refresh=_.filter( $scope.data,function(obj,index){
					obj.index=index;
					return obj.match[$scope.refresh_mag_sel].currentprice==-2;
		});
		
		
		$scope.num_refresh_total=$scope.array_refresh.length;
		$scope.num_refresh_done=0;
	
	
		if($scope.num_refresh_total>0){
	
			var waitmodalInstance =$modal.open({
				templateUrl:"waitModal.html",
				scope: $scope,
				size: 'sm'			
			});

	
			$scope.myVar=setInterval(function () {
					console.log("interval continues");
					if($scope.exec_flag==true){
										
						$scope.exec_flag=false;
						
						var product=$scope.array_refresh[$scope.num_refresh_done];		
						var article=$scope.array_refresh[$scope.num_refresh_done].match[$scope.refresh_mag_sel];
						$scope.refresh_name=product.name;
						
						$http.post('/action/price_refresh',{"compte_name":$scope.compte, 'article_id':article._id, 'product_id':product._id, 'site_id':article.site, 'url':article.url, 'proxy_type':$scope.proxy_type, 'proxy_addr':$scope.proxy_addr}).success(function(data){
							
							$scope.data[product.index].match[$scope.refresh_mag_sel].currentprice=data.price;
							//$scope.data[i].match[j].stock=data.stock;
							//$scope.data[i].match[j].html=data.html;
							
							if(data.price==-2) $scope.exec_num_fail++;
							$scope.num_refresh_done++;
							$scope.exec_flag=true;
							if($scope.num_refresh_done>=$scope.num_refresh_total){
								clearInterval($scope.myVar);
								$scope.status=false;
								waitmodalInstance.close();
								alert($scope.exec_num_fail+" sur "+$scope.num_refresh_total+" fails ");
								$scope.exec_num_fail=0;
								$scope.array_refresh=[];
							}

						}).error(function(data, status, headers, config) {
							alert("Erreur");
						});				
					
					}
				
				
			}, 1000);
		}
		else{
			alert("0/0");
			$scope.status=false;
		}

	}
//*************************************
//           modal function
//*************************************
	
    $scope.openmodal = function(modal_id,data_trans,modaltype,index_i,index_j){
		
		console.log("i"+index_i);
		console.log("j"+index_j);
		console.log(modaltype);
		
		var modalInstance =$modal.open({
			templateUrl: modal_id,
			controller:"ModalInstanceCtrl",
			resolve:{
				sites: function(){return $scope.sites},
				data: function(){return data_trans},
				compte: function(){return $scope.compte},
				modaltype:function(){return modaltype},
				proxy_addr:function(){return $scope.proxy_addr},
				proxy_type:function(){return $scope.proxy_type}
			}
		});
		
		
		modalInstance.result.then(function (data) {

			if(data.modaltype=="modifyUrlBase"||data.modaltype=="deleteUrlBase"){
				$scope.data[index_i].match[index_j]=data.value;
			}

		}, function () {
			console.log("finished modal");
		});
		
	};



//*************************************
//      function action
//*************************************

	$scope.refresh_price= function(product,article,i,j){
		
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html",
			size: 'sm'
		});

		$http.post('/action/price_refresh',{"compte_name":$scope.compte, 'article_id':article._id, 'product_id':product._id, 'site_id':article.site, 'url':article.url, 'proxy_type':$scope.proxy_type, 'proxy_addr':$scope.proxy_addr}).success(function(data){     
			waitmodalInstance.close();

			$scope.data[i].match[j].currentprice=data.price;
			//$scope.data[i].match[j].stock=data.stock;
			//$scope.data[i].match[j].html=data.html;

		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});
	};

	$scope.modifyUrl = function(product, article, index_i, index_j){
		
		var data_trans={"article_id":article._id, "product_id":product._id,"site_id":article.site, "currentname":product.name,"url":article.url,"price":article.currentprice};
		$scope.openmodal("modifyUrlModal.html",data_trans,"modifyUrlBase",index_i,index_j);	
	}
	
//*************************************
//        other function
//*************************************

	$scope.goToProductPage = function(article) {
		if(article.url!=""){
			window.open(article.url);
		}
	};  	
	
	$scope.stoptime=function(){

		clearInterval($scope.myVar);
		$scope.exec_num_fail=0;
		$scope.array_refresh=[];
		$scope.exec_flag=true;
		$scope.status=false;				
	};
	
	$scope.save_ip=function(){
		var now=new Date();
		$http.post('/user/putproxy',{"user":$scope.user, "ip":$scope.proxy_addr,"comment":"Added "+now.toLocaleString()}).success(function(data){
			alert("saved");
			$scope.ips_save.push({"ip":$scope.proxy_addr,comment:"Added "+now.toLocaleString()});
		}); 
	};
	$scope.put_ip=function(ip){
		$scope.proxy_addr=ip;
	};	
	
//*************************************
//        default
//*************************************	
	
	$scope.do_change();
	$http.post('/user/getproxy',{user:$scope.user}).success(function(data){
		$scope.ips_save=data.proxy_list;
	}); 
	
}])

.controller( 'ModalInstanceCtrl',function ($scope, $modalInstance, $http, $modal, sites,data,compte,modaltype,proxy_type,proxy_addr) {

  $scope.sites=sites;
  $scope.data=data;
  $scope.compte=compte;
  $scope.proxy_addr=proxy_addr;
  $scope.proxy_type=proxy_type;

  $scope.rv=[];
  
  if(modaltype=="modifyUrlBase")
  {
	$scope.article_id=data.article_id;
	$scope.product_id=data.product_id;
	$scope.site_id=data.site_id;
	$scope.currentname=data.currentname;
	$scope.price=data.price;
	$scope.thisurl=data.url;
  }


  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
  
 
	
 	$scope.modifyThisUrl = function(url){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html",
			size: 'sm'			
		});

		$http.post('/action/price_modifyUrl',{"compte_name":$scope.compte, 'article_id':$scope.article_id, 'product_id':$scope.product_id, 'site_id':$scope.site_id, 'url':url, 'proxy_type':$scope.proxy_type, 'proxy_addr':$scope.proxy_addr}).success(function(data){     
			waitmodalInstance.close();
			$scope.rv.modaltype="modifyUrlBase";
			$scope.rv.value=data;
			waitmodalInstance.close();
			$modalInstance.close($scope.rv);
			
		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});
		
	} 

});
