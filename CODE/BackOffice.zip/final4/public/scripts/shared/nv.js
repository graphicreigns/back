APP.controller('NVCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');

	$scope.title="Gestion de NV";
	$scope.compte="aqualung";

	//$scope.data=[{"type":1,"name":"name1","magasin":"Nootica","date_insert":"01/01/2015"}];

	
	var now=new Date();
	var today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
	var demain= new Date(today.getTime()+24*3600*1000);
	var plus_deux= new Date(today.getTime()+24*3600*1000*2);
	var plus_sept= new Date(today.getTime()+24*3600*1000*7);
	//var moins_sept= new Date(today.getTime()-24*3600*1000*7);

	$scope.data_show=[];
	$scope.data_all=[];
	$scope.num_show=0;
	$scope.duree={"type1":true,"type2":true,"type3":false,"type4":false,"type5":false};

	
	$scope.do_filter=function(){
		
		var tmp_array=_.filter($scope.data_all, function(obj){ return $scope.duree[obj.type] })
		$scope.data_show=_.sortBy(tmp_array, function(obj){return obj.date_exp.getTime()});
		$scope.num_show=$scope.data_show.length;
	}

	$scope.do_change=function(){
		
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html",
			size: 'sm'
		});
	
		$http.post('/gestion/nv',{"user_name":$scope.compte}).success(function(data) {
	
			waitmodalInstance.close();		
			
			_.map(data,function(obj){
				var date_tmp=new Date(obj.date_exp);
				if(date_tmp<today) obj.type="type1";
				if(date_tmp>=today&&date_tmp<demain) obj.type="type2";
				if(date_tmp>=demain&&date_tmp<plus_deux) obj.type="type3";
				if(date_tmp>=plus_deux&&date_tmp<plus_sept) obj.type="type4";
				if(date_tmp>=plus_sept) obj.type="type5";
				
				obj.date_exp=date_tmp;
				obj.date_exp_show=""+date_tmp.getDate()+"/"+(date_tmp.getMonth()+1)+"/"+date_tmp.getFullYear();
			});			
				
			$scope.data_all=data;
			$scope.do_filter();
			
		});
	}
	
	$scope.do_change();
	
	
}])
