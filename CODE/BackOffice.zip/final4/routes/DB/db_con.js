var mongojs = require('mongojs')
var db=mongojs('localhost/HRPP01');

//var db = mongojs('91.121.103.86:27017/HRPP01');

var getcollection=function(name){

	return db.collection(name);
}

var getconfig=function(){

	var path_price="/home/mao/workspace/GETPRICE";
	//var path_price="/root/BSWEB/GETPRICE";	
	
	return {path_price:path_price};
}

module.exports.collection =getcollection;
module.exports.config =getconfig;
