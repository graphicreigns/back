var phantom = require('phantom');

process.on('message', function(msg) {
	
	
	console.log('CHILD got message:', msg.url);
	
 	phantom.create(function (ph) {
		ph.createPage(function (page) {
			page.open(msg.url, function (status) {
				
			  page.evaluate(function () { 
				  
				var return_price_value="-2";
				var return_stock_value="";
				var return_html_value=false;

				var host=location.hostname;	

				var return_html= document.getElementById("tab_models"); 
				var stock_table={"En Stock":"en stock", "Sous 48 H":"3-5 jours" , "Sous 72 H":"3-5 jours", "Sous 8 Jours":"+5 jours", "Sous 10 Jours":"+5 jours", "Supérieur à 15 Jours":"+5 jours","Epuisé":"rupture"};
				
				if(return_html!=null&&host.indexOf("scubaland")!=-1){
					
					var price_index=5;
					if(document.getElementsByClassName("prixpriv").length==0&&document.getElementsByClassName("prixprivvf").length==0) price_index=4;  
					
					
					if(return_html.rows.length==2){
						
						return_price_value=return_html.rows[1].cells[price_index].textContent;
						return_stock_value=stock_table[return_html.rows[1].cells[2].children(1).textContent.replace(/(^\s*)|(\s*$)/g, "")];
						
					}
					else{
						
						var price=return_html.rows[1].cells[price_index].textContent;				
							price=price.replace(/(^\s*)|(\s*$)/g, "");  //delete space
							price=price.replace('€',"");						
						var meilleur_prix=parseFloat(price);

						var stockage={"En Stock":3,"Sous 10 Jours":3, "Sous 8 Jours":3,"Sous 72 H":2,"Sous 48 H":2,"Supérieur à 15 Jours":1,"Epuisé":0};	
						var return_stockage=["rupture","+5 jours","3-5 jours","en stock"];
						var meilleur_stock=0;	   //le plus gros, le plus en stock	
						
											
						for(var i=0;i<return_html.rows.length;i++){
		
							if(i>0){
								
								price=return_html.rows[i].cells[price_index].textContent;				
								price=price.replace(/(^\s*)|(\s*$)/g, "");  //delete space
								price=price.replace('€',"");						
								
								if(parseFloat(price)<meilleur_prix)	 meilleur_prix=parseFloat(price);
								
								if(stockage[return_html.rows[1].cells[2].children(1).textContent.replace(/(^\s*)|(\s*$)/g,"")]>meilleur_stock){
									meilleur_stock=stockage[return_html.rows[1].cells[2].children(1).textContent.replace(/(^\s*)|(\s*$)/g, "")];
								}
									
								return_html.rows[i].deleteCell(3);	
															
							}
							else{
								return_html.rows[i].deleteCell(2);
							}
						}
						
						return_price_value=""+meilleur_prix+"";			
						return_stock_value=return_stockage[meilleur_stock];
						return_html_value=return_html.outerHTML;						
		
					}
		
				}

				  
				return {
					  price: return_price_value,
					  stock: return_stock_value,
					  html: return_html_value
					 }; 
				  
			  }, function (result) {
				   
					price=result.price.replace(/(^\s*)|(\s*$)/g, "");  //delete space
					price=price.replace('€',"");
					if(isNaN(price)) price="-2";				
					console.log('Price is ' + price);
					
					
					process.send({ price: parseFloat(price), stock: result.stock, html:result.html, img_url:""});
					process.exit();
			  });				
				
	
				
			});
		});
	});
	
});


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
						
