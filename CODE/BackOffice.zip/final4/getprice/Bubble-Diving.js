var phantom = require('phantom');
var exec = require('child_process').exec;
var path = require('path');

process.on('message', function(msg) {
	
	console.log('CHILD got message:', msg);	
	var file_path=path.resolve(__dirname);
	//104.143.5.133:7808
	//var france_url=msg.url+"?shipping-county=FR";
	// exec("phantomjs --proxy=localhost:9050 --proxy-type=socks5 "+file_path+"/VPN.js "+msg.url,function(err,stdout,stderr){
	exec("phantomjs --proxy="+msg.proxy_addr+" --proxy-type="+msg.proxy_type+" "+file_path+"/VPN_old.js "+msg.url,function(err,stdout,stderr){	
		  console.log(stdout);
		  //console.log(err);
		  //console.log(stderr);
		 /* if (err) return callback(err);
		  if (stderr) return callback(stderr);
		  if (parseInt(stdout) == 1) callback(null,1);
		  else callback(null,0);*/
			
			var out_json=stdout.substring(stdout.indexOf("string begins here:")+20);
			
			process.send(JSON.parse(out_json));
			process.exit();
					
			
	  });	
});


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
						
