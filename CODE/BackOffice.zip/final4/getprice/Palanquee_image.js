var phantom = require('phantom');

process.on('message', function(msg) {
					
	console.log('CHILD got message:', msg.url);		
	
 	phantom.create(function (ph) {
		ph.createPage(function (page) {
			
			//page.settings.userAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko)';
			
			page.open(msg.url, function (status) {
			  //console.log("opened google? ", status);
				
			  page.evaluate(function () { 
				  
				//price  
				var return_price_value="-2";
				var return_stock_value="";
				var return_html_value=false;
				var return_image_url="";
				
								
				var return_price=  document.getElementsByClassName("productPrice"); 
				if(return_price.length>0){
					return_price_value=return_price[0].textContent;
				}
				
				//stock

				var return_stock=document.getElementById("imgAvai");
				if(return_stock!=null){
					return_stock_value=return_stock.alt;
				}
				
				//url_img
				var return_img=document.getElementsByClassName("browseProductImage");
				var return_img2=document.getElementById("slideshowImage");
				if(return_img.length>0){
					return_image_url=return_img[0].src;
				}
				else if(return_img2!=null){
					return_image_url=return_img2[0].src;
				}
				
				 //table
				if((document.getElementById("imgAvai")==null)&&(document.getElementsByClassName("vmCartDetails").length>0)){
					
					var return_html=  document.getElementsByClassName("vmCartDetails")[0].getElementsByTagName("table")[0];
					var stockage={"en_stock.png":4,"5_days.png":3,"7_days.png":2,"rupture.png":1};	
					var return_stockage=["rupture.png","7_days.png","5_days.png","en_stock.png"];
					var meilleur_stock=1;	
					var index_stock="rupture.png";
					
					if(return_html.rows.length>1){
						
						var nb_col=return_html.rows[0].cells.length;
							
						for(var i=0;i<return_html.rows.length;i++){
							if(return_html.rows[i].cells[2].getElementsByTagName("span").length>0)
								return_html.rows[i].cells[2].getElementsByTagName("span")[0].textContent="";
								
								
							index_stock=return_html.rows[i].cells[nb_col-1].getElementsByTagName("img")[0].alt;
							if(stockage[index_stock]>meilleur_stock) meilleur_stock=stockage[index_stock];
							
							return_html.rows[i].cells[nb_col-1].getElementsByTagName("img")[0].src=return_html.rows[i].cells[nb_col-1].getElementsByTagName("img")[0].src;
							
							return_html.rows[i].deleteCell(0);
							return_html.rows[i].deleteCell(2); //c'est la troisime en fact
							if(nb_col>5) return_html.rows[i].deleteCell(2);  //c'est la quatrieme en fact
													
						}
						
						return_stock_value=return_stockage[meilleur_stock-1];
						return_html_value=return_html.outerHTML;
					}


				  }
				  
					return {
						  price: return_price_value,
						  stock: return_stock_value,
						  html: return_html_value,
						  img_url: return_image_url
					}; 
	
					
				  
			  }, function (result) {
				   
					price=result.price.replace(/\s*/g, "");  //delete space
					price=price.replace('€',"");
					price=price.replace(',',".");
					//if(isNaN(price)) price="-2";		
					console.log('---Price is ' + price);				
					console.log('---Stock is '+result.stock);
					console.log('---Url is '+result.img_url);
										
					var stockage={"en_stock.png":"en stock","5_days.png":"3-5 jours","7_days.png":"+5 jours","rupture.png":"rupture"};	
					tmp_stock=stockage[result.stock];

					//process.send({ price: parseFloat(price), stock: tmp_stock, html:result.html, img_url:""});
					process.send({ price: parseFloat(price), stock: tmp_stock, html:result.html, img_url:result.img_url});
					process.exit();
			  });				
		
			});
		});
	});
	
});

