var phantom = require('phantom');

process.on('message', function(msg) {
	
	
	 console.log('CHILD got message:', msg.url);
	
	var true_url="http://www.simplyscuba.com/ChangeCurrency.aspx?Currency=EUR&Country=&FromURL="+msg.url;
	
 	phantom.create(function (ph) {
		ph.createPage(function (page) {
			page.open(true_url, function (status) {
				
			  page.evaluate(function () { 
				  
				  
				//price  
				var return_price_value="-2";
				var return_price= document.getElementById("productPrice");  
	
				var host=location.hostname;
				if(host.indexOf("simplyscuba")!=-1){
				
					if(return_price!=null){
						return_price_value=return_price.textContent;
					}
					
					/*//stock
					var return_stock_value="en stock";
					var return_stock=document.getElementById("imgAvai");

					if(return_stock!=null){
						return_stock_value=return_stock.alt;
					}*/
				  
				}  
				  
				  return {
						  price: return_price_value,
				          stock: "en stock"
				         }; 
				  
			  }, function (result) {
				   
					price=result.price.replace(/(^\s*)|(\s*$)/g, "");  //delete space
					price=price.replace('€',"");
					price=price.replace(',',"");
					if(isNaN(price)) price="-2";				
					console.log('Price is ' + price);
					

					process.send({ price: parseFloat(price), stock: "", html:false, img_url:""});
					process.exit();
			  });				
				
	
				
			});
		});
	});
	
});


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
						
