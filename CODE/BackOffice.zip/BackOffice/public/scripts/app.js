  'use strict';
   var APP=angular.module('app', ['n3-line-chart','ngCookies','ngRoute','ngSanitize', 'ngAnimate', 'ui.bootstrap', 'easypiechart', 'mgo-angular-wizard', 'textAngular', 'angular-loading-bar', 'app.ui.ctrls', 'app.ui.directives', 'app.ui.services', 'app.controllers', 'app.directives', 'app.form.validation', 'app.ui.form.ctrls', 'app.ui.form.directives', 'app.tables', 'app.task', 'app.localization', 'app.chart.ctrls', 'app.chart.directives']).config([
    '$routeProvider', function($routeProvider) {
     $routeProvider.when('/', {
        redirectTo: '/pages/signin'
      }).when('/dashboard', {
        templateUrl: 'views/compte.html'
      }).when('/utilisateur', {
        templateUrl: 'views/utilisateur.html'
      }).when('/magasin', {
        templateUrl: 'views/magasin.html'   
      }).when('/PERF/comment', {
        templateUrl: 'views/comment_gestion.html'
      }).when('/PERF/graph', {
        templateUrl: 'views/graph_gestion.html'
      }).when('/SPE/conf', {
        templateUrl: 'views/configue_SPE.html'
      }).when('/SPE/nv', {
        templateUrl: 'views/nv.html'
      }).when('/SPE/alert', {
        templateUrl: 'views/alert.html'
      }).when('/SPE/re_sta', {
        templateUrl: 'views/regenerer.html'
      }).when('/SPE/n_refresh', {
        templateUrl: 'views/n_refresh.html'
      }).when('/SPE/alert', {
        templateUrl: 'views/alert.html'
      }).when('/compte', {
        templateUrl: 'views/compte.html'   
      }).when('/SPE/proxy', {
        templateUrl: 'views/proxy.html'   
      }).when('/pages/signin', {
        templateUrl: 'views/pages/signin.html',
        controller: 'LoginCtrl'
      }).when('/404', {
        templateUrl: 'views/pages/404.html'
      }).when('/pages/500', {
        templateUrl: 'views/pages/500.html'
      }).when('/pages/blank', {
        templateUrl: 'views/pages/blank.html'
      }).when('/pages/invoice', {
        templateUrl: 'views/pages/invoice.html'
      }).when('/tasks', {
        templateUrl: 'views/tasks/tasks.html'
      }).otherwise({
        redirectTo: '/404'
      });
    }
  ]).factory('_', function() {
	return window._; // assumes underscore has already been loaded on the page
  }).factory('getcookie', function(){
	  
	return function(data){
		var e = document.getElementById('app_ctrl');
		var scope = angular.element(e).scope();
	   
		scope.main.name=data.site_name;
		//scope.main.url_logo=data.url_img;
		//scope.main.update=data.update;
		//scope.main.notice=data.notice;
		//scope.main.supplier=data.supplier;
				
		angular.element(document.getElementById('lang_ctrl')).scope().lang=data.lang.name;
	}
  }).run(function ($rootScope, $cookieStore, $location) {
        $rootScope.$on("$routeChangeStart", function (event, next, current) {

            if ($cookieStore.get('userID_admin') == undefined) {
				
				$location.path("/pages/signin");

            }
            
        });
    });
