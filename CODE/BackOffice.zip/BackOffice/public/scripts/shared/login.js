
APP.controller('LoginCtrl', ['$scope', '$location', '$cookieStore', '$rootScope', '$http','localize','getcookie', function ($scope, $location, $cookieStore, $rootScope, $http, localize,getcookie) {

    $rootScope.page = "login";

    var logout = function logout() {
        $cookieStore.remove('userID_admin');
        //$cookieStore.remove('supplier');
        $cookieStore.remove('lang_admin');

		/*var child=document.getElementById("chat");
		if(child!=null){
			window.location.reload();
		}*/
    }; logout();

    $scope.checkLogin = function () {
		
		$scope.user=$("#user-tf").val();
		$scope.pass=$("#pass-tf").val();
		
        $http.get('/user/'+$scope.user+'/'+$scope.pass).success(function(data) {
			
               if (data.ok == 1)
               {
                   $cookieStore.put('userID_admin', data.docs._id);
                  // $cookieStore.put('supplier',data.docs.supplier);
                   $cookieStore.put('lang_admin',data.docs.lang.sign);
                   
                    localize.setLanguage(data.docs.lang.sign);
                    
					getcookie(data.docs);
	
                   
                   /*if(data.login=="aqualung"){
						var s = document.createElement('script'); // use global document since Angular's $document is weak
						s.id = 'chat';
						s.src='scripts/chat_aqu.js';
						document.body.appendChild(s);
				   }*/
                   
					$location.path("/dashboard");

               }
                else{
                   alert('Combinaison invalide');
               }
            });
    };
    
}]);
