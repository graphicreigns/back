APP.controller('ConfigueCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');

	$scope.title="Configuration SPE";
	

}]);
