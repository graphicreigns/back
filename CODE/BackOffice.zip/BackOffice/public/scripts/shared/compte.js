APP.controller('CompteCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');

	$scope.title="Gestion de compte -- Global";
	
	$scope.sites_SPE=[];
	$scope.sites_WASA=[];
	$scope.sites_PERF=[];
	
	$scope.module={
		SPE:true,
		WASA:true,
		PERF:true,
		MAIL:false
	};
	
	$http.post('/compte/all_compte').success(function(data) {
		$scope.comptes=data;
		$scope.num_total=data.length;
		
	});

	$http.post('/compte/getallsite').success(function(data) {
		$scope.sites=data;
	});
	
/************************************
 * 
 * modal function
 * 
 * */
 
 	$scope.cancel = function () {
		$scope.tmp="";
		$scope.addmodalInstance.dismiss('cancel');
	};
 
	$scope.AddCompte=function(){
		$scope.addmodalInstance =$modal.open({
			templateUrl:"newcompteModal.html",
			scope: $scope,
		});
	};
	
	$scope.additem=function(selectedItem,dest){
		
		for(var i=0;i<selectedItem.length;i++){
			var tmp= angular.fromJson(selectedItem[i]);
			var tmp_obj={};
			tmp_obj._id=tmp._id;
			tmp_obj.name=tmp.name;
			if(_.findLastIndex(dest,{_id:tmp._id})<0){
				dest.push(tmp_obj);
			}
		}

	};
	
	$scope.clearitem=function(selectedItem,dest){
		
		for(var i=0;i<selectedItem.length;i++){
			var tmp= angular.fromJson(selectedItem[i]);
			if(_.findLastIndex(dest,{_id:tmp._id})>=0){
				dest.splice(_.findLastIndex(dest,{_id:tmp._id}), 1);
			}
		}

	};	

	$scope.addCompteBase=function(username,url_img,supplier,module){
		
		$http.post('/compte/add_compte',{site_name:username, supplier:supplier, site:$scope.sites_SPE, site_WASA:$scope.sites_WASA, site_PERF:$scope.sites_PERF, module:module}).success(function(data) {
			$scope.comptes.push(data);
			$scope.addmodalInstance.dismiss('cancel');				
		});
	};	


	
/************************************
 * 
 * 
 * */	

	$scope.confirm = function(user_id){
		$scope.tmp=user_id;
		$scope.addmodalInstance =$modal.open({
			templateUrl:"confirmModal.html",
			scope: $scope,
		});		
	};

	$scope.deleteThis = function(compte_id){
		
		$http.post('/compte/delete_compte',{compte_id:compte_id}).success(function(data) {
			$scope.comptes=_.reject($scope.comptes, function(obj){ return obj._id == compte_id; });
			$scope.addmodalInstance.dismiss('cancel');				
		});		
	};	

}]);
