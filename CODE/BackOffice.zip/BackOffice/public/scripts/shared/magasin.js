APP.controller('MagasinCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');

	$scope.title="Gestion de magasins";
	
	//$scope.contenu_M={};
	
	$http.post('/compte/getallsite').success(function(data) {
		$scope.magasins=data;
		$scope.num_total=data.length;
		
	});

/************************************
 * 
 * 
 * */	

 	$scope.cancel = function () {
		$scope.tmp="";
		$scope.addmodalInstance.dismiss('cancel');
	};

	$scope.AddMagasin = function(magasin){
		$scope.addmodalInstance =$modal.open({
			templateUrl:"newMagasinModal.html",
			scope: $scope,
		});		
	};


	$scope.modify = function(magasin){
		$scope.tmp=magasin._id;
		$scope.contenu_M=magasin;
		$scope.addmodalInstance =$modal.open({
			templateUrl:"modifyModal.html",
			scope: $scope,
		});		
	};

	$scope.confirm = function(site_id){
		$scope.tmp=site_id;
		$scope.addmodalInstance =$modal.open({
			templateUrl:"confirmModal.html",
			scope: $scope,
		});		
	};

/************************************
 * 
 * 
 * */

	$scope.addMagasinBase=function(name,url,color){
		$http.post('/compte/add_site',{name:name, url:url, color:color}).success(function(data) {

			$scope.magasins.push(data);
			$scope.addmodalInstance.dismiss('cancel');				
		});			
		
	};

	$scope.ModifyMagasinBase=function(name,url,color){
		$http.post('/compte/update_site',{site_id:$scope.tmp, name:name, url:url, color:color}).success(function(data) {
			
			$scope.addmodalInstance.dismiss('cancel');				
		});			
		
	};
	
	
	$scope.deleteThis = function(site_id){
		
		$http.post('/compte/delete_site',{site_id:site_id}).success(function(data) {
			$scope.magasins=_.reject($scope.magasins, function(obj){ return obj._id == site_id; });
			$scope.addmodalInstance.dismiss('cancel');				
		});		
	};

}]);
