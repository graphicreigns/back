APP.controller('ProxyCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize', function ($scope, $location, $cookieStore, $http, $modal, localize) {

	$scope.user = $cookieStore.get('userID_admin');
		
	$scope.title="Gestion de Proxy";
	$scope.proxy_addr="localhost:9050";
	$scope.proxy_type="http";
	
	$scope.ips_save=[];
	$scope.rapport={};
	$scope.AddIp="";
	$scope.AddComment="";
	
	$scope.flag_roue=true;	
	
	$scope.test_list=[
		{
			url:"http://www.palanquee.com/magasin-plongee-news/accueil/montres-ordinateurs/ordinateur-d4i-montre-2014-interface-usb-suunto-blanc?vmcchk=1",
			magasin:"Palanquee",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://www.scubazar.fr/ordinateurs/montres-ordinateurs/montre-ordinateur-suunto-d4i-novo-blanche-avec-interface-usb.html",
			magasin:"Scubazar",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"https://www.mareshop.eu/dive_eu_fr/plongee/instruments/ordinateurs/suunto-d4i-novo",
			magasin:"Mareshop",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://www.auvieuxcampeur.fr/d4i-usb-2014.html",
			magasin:"Au vieux campeur",
			status:"Waiting",
			price: 0,
			time: 0
		},		
		{
			url:"http://www.vieuxplongeur.com/fr/ordinateurs/17679-montre-d4i-novo-pochon-offert.html",
			magasin:"VieuxPlongeur",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://www.bubble-diving.com/plonge/d4i-white-novo-computer-with-usb-cable.html",
			magasin:"Bubble-Diving",
			status:"Waiting",
			price: 0,
			time: 0
		}/*,

		{
			url:"http://www.scubastore.com/plongee/suunto-d4i-novo-white/554957/p",
			magasin:"Scubastore",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://www.scubaland.fr/ordinateur-suunto-d4i-novo-blanc-suunto.html",
			magasin:"Scubaland",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://www.ts-heinemann.com/products/de/Tauchcomputer/Suunto-D4i-Novo-Tauchcomputer.html",
			magasin:"Ts-heinemann",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"https://www.mareshop.eu/dive_eu_fr/plongee/instruments/ordinateurs/suunto-d4i-novo",
			magasin:"Mareshop",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://www.simplyscuba.com/products/Suunto/D4iNovoDiveComputer.aspx",
			magasin:"Simplyscuba",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://www.lucasdivestore.com/divegear/comp-watches/computer-air-integrated/suunto-d4i-novo.html",
			magasin:"Lucasdivestore",
			status:"Waiting",
			price: 0,
			time: 0
		},
		{
			url:"http://aquastory.eu/ordinateurs-suunto/673-d4i-novo-noire.html?search_query=d4i",
			magasin:"Aquastory",
			status:"Waiting",
			price: 0,
			time: 0
		}*/
	];
	
	
	$scope.ClearSelected = function(){

		$scope.ips_save.forEach(function(element){

			if(element.deleted==true){
				$http.post('/user/deleteproxy',{"user":$scope.user, "ip":element.ip}).success(function(data){	  
					alert("deleted "+element.ip);
				});	
			}
		});	
		  
		$scope.ips_save = $scope.ips_save.filter( function(eachone){
			return !eachone.deleted;
		})
	};

	$scope.AddToList = function(){

		if($scope.AddIp!=""){
			$http.post('/user/putproxy',{"user":$scope.user, "ip":$scope.AddIp,"comment":$scope.AddComment}).success(function(data){
				alert("saved");
				$scope.ips_save.push({"ip":$scope.AddIp, "comment":$scope.AddComment});
				
				$scope.AddIp="";
				$scope.AddComment="";
			});
		}
		else{
			alert("entree null");
		} 			

	};
	
	$scope.Testproxy = function(){
		$scope.proxy_test=$scope.proxy_addr;
		
		
		var exec_flag=true;
		var i=0;		
		
		$scope.num_refresh_total=$scope.test_list.length;
		$scope.num_refresh_done=0;
	
	
		if($scope.num_refresh_total>0){
	
			var waitmodalInstance =$modal.open({
				templateUrl:"waitModal.html",
				scope: $scope,
				size: 'sm'			
			});

	
			$scope.myVar=setInterval(function () {
					i++;
					console.log("interval continues");
					if(exec_flag==true){
										
						exec_flag=false;
						
						//var product=$scope.array_refresh[$scope.num_refresh_done];		
						var article=$scope.test_list[$scope.num_refresh_done];
						$scope.refresh_name=article.magasin;
						
						$http.post('/action/price_test',{'site':article.magasin, 'url':article.url, 'proxy_type':$scope.proxy_type, 'proxy_addr':$scope.proxy_addr}).success(function(data){
							
							article.price=data.price;
							if(data.price>0){
								article.status="passe";
							}
							else{
								article.status="fails";
							}
							
							article.time=i;
							i=0;
							$scope.num_refresh_done++;
							exec_flag=true;
							if($scope.num_refresh_done>=$scope.num_refresh_total){
								clearInterval($scope.myVar);
								waitmodalInstance.close();
							}

						}).error(function(data, status, headers, config) {
							alert("Erreur");
						});				
					
					}
				
				
			}, 1000);
		}
		else{
			alert("0/0");
		}		
	}
	
	$scope.put_ip = function(ip){
		$scope.proxy_addr=ip;
	}
	
	$scope.Stoptime=function(){

		clearInterval($scope.myVar);
		$scope.test_list=[
			{
				url:"http://www.palanquee.com/magasin-plongee-news/accueil/montres-ordinateurs/ordinateur-d4i-montre-2014-interface-usb-suunto-blanc?vmcchk=1",
				magasin:"Palanquee",
				status:"Waiting",
				price: 0,
				time: 0
			},
			{
				url:"http://www.scubazar.fr/ordinateurs/montres-ordinateurs/montre-ordinateur-suunto-d4i-novo-blanche-avec-interface-usb.html",
				magasin:"Scubazar",
				status:"Waiting",
				price: 0,
				time: 0
			},
			{
				url:"https://www.mareshop.eu/dive_eu_fr/plongee/instruments/ordinateurs/suunto-d4i-novo",
				magasin:"Mareshop",
				status:"Waiting",
				price: 0,
				time: 0
			},
			{
				url:"http://www.auvieuxcampeur.fr/d4i-usb-2014.html",
				magasin:"Au vieux campeur",
				status:"Waiting",
				price: 0,
				time: 0
			},		
			{
				url:"http://www.vieuxplongeur.com/fr/ordinateurs/17679-montre-d4i-novo-pochon-offert.html",
				magasin:"VieuxPlongeur",
				status:"Waiting",
				price: 0,
				time: 0
			},
			{
				url:"http://www.bubble-diving.com/plonge/d4i-white-novo-computer-with-usb-cable.html",
				magasin:"Bubble-Diving",
				status:"Waiting",
				price: 0,
				time: 0
			}
		];	
						
	};	
	
	
	/*
	 *  pour rapport_proxy
	 **/
	$scope.show_heure=function(string){
		var time= new Date(string);
		return time.getHours()+":"+time.getMinutes();
	};
	$scope.show_table=function(string){
		var waitmodalInstance =$modal.open({
			templateUrl:"table.html",
			controller:"ModalTableCtrl",
			size:"lg",
			resolve:{
				content: function(){return string}
			}
		});
	};	
	/*
	 *  default
	 **/
	$http.post('/user/getproxy',{user:$scope.user}).success(function(data){
		$scope.ips_save=data.proxy_list;
		_.map($scope.ips_save,function(obj){obj.deleted=false});
	});
	
	$http.post('/user/getrapport').success(function(data){
		$scope.rapport=data;
	}); 
	
}]);

APP.controller( 'ModalTableCtrl',['$scope','$modalInstance','content', function($scope,$modalInstance,content) {

  $scope.content=content;

  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };

}]);

