var express = require('express');
var router = express.Router();

var users = require('./routes/users');
var gestion = require('./routes/gestion');
var action = require('./routes/action');
var compte = require('./routes/compte');
var graphic = require('./routes/graphic');

router.get('/', function(req, res) {
  res.render('index', { title: 'Express' });
});

router.use('/user', users);
router.use('/compte',compte);
router.use('/action',action);
router.use('/gestion', gestion);
router.use('/graphic', graphic);

module.exports = router;
