var phantom = require('phantom');

process.on('message', function(msg) {
	
	
	console.log('CHILD got message:', msg);
	
	phantom.create({
	  parameters: {
		'proxy': msg.proxy_addr,
		'proxy-type': msg.proxy_type
	  }
	}, function(ph) {
		
		ph.createPage(function (page) {
			page.open(msg.url, function (status) {
				
			  page.evaluate(function () { 
				  
				//price  
				var return_price_value="-2";
				
				var host=location.hostname;	
				
				if(host.indexOf("mareshop")!=-1){
				
					var return_price= document.getElementsByTagName("span");  
					
					if(return_price.length>0){
						for(var i=0;i<return_price.length;i++){
							if(return_price[i].id.indexOf("product-price")==0){
								return_price_value=return_price[i].textContent;
							}
						}
					}
					
					/*//stock
					var return_stock_value="en stock";
					var return_stock=document.getElementById("imgAvai");

					if(return_stock!=null){
						return_stock_value=return_stock.alt;
					}*/
				 }

				  return {
						  price: return_price_value,
				          stock: "en stock"
				         }; 
				  
			  }, function (result) {
				  
				    price=result.price.replace(/\s*/g, "");  //delete space
					price=price.replace('€',"");
					price=price.replace(',','.');	
					if(isNaN(price)) price="-2";			
					console.log('Price is ' + price);
					
					process.send({ price: parseFloat(price), stock: "", html:false, img_url:""});
					process.exit();
			  });				
				
	
				
			});
		});
	});
	
});
