var mongojs = require('mongojs')
var db=mongojs('localhost/BO_ADMIN');
//var db=mongojs('91.121.103.86:27017/BO_ADMIN');

var getcollection=function(name){

	return db.collection(name);
}

module.exports.collection =getcollection;
