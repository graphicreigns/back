var cp=require('child_process');
var path = require('path');
var http = require('http');
var fs = require('fs');

var db = require("./db_con");

var getprice=function(sitename,url,proxy_type,proxy_addr,callback){

	var file_path=db.config().path_price;
	var n=cp.fork(file_path+"/create_ph.js");

    console.log("xxxxx",proxy_addr);
	if(proxy_addr=="(no proxy)"){
		n.send({ url: url, site:sitename, hasproxy:false });
	}
	else{
		n.send({ url: url, site:sitename, hasproxy:true, proxy_type:proxy_type, proxy_addr:proxy_addr });
	}
	
	n.on('message', function(msg) {
	  console.log('PARENT got message:', msg);
	  
	  callback(null,msg);
	});
}



var after_getprice_modify=function(ARTICLES,PH,article_id,result,callback){
	
	ARTICLES.update({_id:article_id},{$set:{currentprice:result.price, stock:result.stock, img_url:result.img_url, html:result.html, NV_bell:result.NV_bell}},function(err){
		
		PH.update({_id:article_id},{$addToSet:{prices:{price:result.price,time:new Date()}}},function(err){
								
			 callback(err,ARTICLES);
		});	
	});
}

module.exports.getprice = getprice;
module.exports.after_getprice_modify=after_getprice_modify;
