var express = require('express');
var router = express.Router();

var async = require('async')
 , mongojs = require('mongojs')
 , _ = require('underscore') 
 , ObjectId = mongojs.ObjectId;

var db = require("./db_con");

var COMPTE=db.collection("compte");
var SITES=db.collection("sites");
var CAT_GEN=db.collection("cat_gen");
var FA=db.collection("followedArticle");



var rangesite=function(compte,thisarray){
	
	var thisarrayfinal=[];

	for(var j=0;j<compte.site.length;j++){

		var flag_existe=false;
		
		for(var k=0;k<thisarray.length;k++)
		{
			//console.log(thisarray[k].site._id);
			
			if( compte.site[j]+'' == thisarray[k].site+'')
			{
				thisarrayfinal.push(thisarray[k]);
				flag_existe=true;
			}
		}
		
		if(flag_existe==false)
		{
			var newArticle = Object.create(null);
			newArticle.currentprice = null;
			newArticle.site=compte.site[j];
			newArticle.NV_bell=false;
			
			thisarrayfinal.push(newArticle);
		}
	}	
	
	return thisarrayfinal;
	
};

var agg_nv=function(idcompte,login,cb){

	var ARTICLES=db.collection("articles_"+login);	
	
	var array_NV=[];
	
	async.waterfall([
		function(callback){
			FA.findOne({id_user:idcompte},callback);
		},
		function(docs,callback){
						
			if(docs.id_article.length>0){
				async.forEach(docs.id_article,function(eacharticle,cb_docs){	
					
					async.forEach(eacharticle.match,function(eachmatch,cb_docs2){
						
						ARTICLES.findOne({_id:ObjectId(eachmatch)},{NV_bell:1,site:1},function(err,article){

							if(article.NV_bell==undefined){
								 console.log(article._id);
							}
							else{
								if(article.NV_bell!=false){
		
									var date_insert=new Date(article.NV_bell.date_insert);
									var date_exp=new Date(date_insert.getTime()+article.NV_bell.jours*3600*24*1000);
									
									var this_insert=Object.create(null);
									this_insert.name=eacharticle.name;
									this_insert.magasin=article.site.name;
									
									this_insert.date_insert_show=article.NV_bell.date_show;
									this_insert.date_exp=date_exp;
									//this_insert.date_exp=""+date_exp.getDate()+"/"+(date_exp.getMonth()+1)+"/"+date_exp.getFullYear();
									
									array_NV.push(this_insert);

								}
							}
							cb_docs2(null);							
							
						});
					},function(err){						
						cb_docs(err);

					});
				},function(err){
					callback(null,null)
				});
			}
			else{
				callback(null,null);
			}
		}
	],function(err){
		
		cb(err,array_NV);
	})

}

var agg_alert=function(compte,cb){

	var ARTICLES=db.collection("articles_"+compte.site_name);	
	
	var all_alert=[];
	
	async.waterfall([
		function(callback){
			FA.findOne({id_user:compte._id},callback);
		},
		function(docs,callback){
			
			if(docs.id_article.length>0){
				async.forEach(docs.id_article,function(eacharticle,cb_docs){	
					
					var flag=false;
					var this_match=[];
					async.forEach(eacharticle.match,function(eachmatch,cb_docs2){
						
						ARTICLES.findOne({_id:ObjectId(eachmatch)},function(err,article){

							article.site=article.site._id;
							if(article.currentprice==-2){
								 flag=true;
							}
								
							this_match.push(article);
							cb_docs2(null);							
							
						});
					},function(err){
						if(flag==true){
							
							eacharticle.match=rangesite(compte,this_match);
							all_alert.push(eacharticle);
						}
												
						cb_docs(err);

					});
				},function(err){
					callback(null,null)
				});
			}
			else{
				callback(null,null);
			}
		}
	],function(err){
		
		cb(err,all_alert);
	})

}


var agg_non_refresh=function(compte,cb){

	var ARTICLES=db.collection("articles_"+compte.site_name);	
	var PH=db.collection("priceHistory_"+compte.site_name);
	
	var all_NonReF=[];
	
	async.waterfall([
		function(callback){
			FA.findOne({id_user:compte._id},callback);
		},
		function(docs,callback){
			
			var now=new Date();
			var today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
			
			if(docs.id_article.length>0){
				async.forEach(docs.id_article,function(eacharticle,cb_docs){	
					
					var flag=false;
					var this_match=[];
					async.forEach(eacharticle.match,function(eachmatch,cb_docs2){
						
						ARTICLES.findOne({_id:ObjectId(eachmatch)},function(err,article){

							article.site=article.site._id;
							
							PH.aggregate(
								{$match:{"_id":ObjectId(eachmatch)}},
								{$unwind: "$prices"},
								{$match:{"prices.time":{$gte:today}}},
								{$group:{'_id':"$_id","prices": {$push: '$prices'}}},
								
								function(err,all_prices){
									
									if(all_prices.length==0&&article.url!=""){
										flag=true;
										article.non_refresh=true;
									}
									else{
										article.non_refresh=false;
									}
									this_match.push(article);
									cb_docs2(null);		
								}
							);												
							
						});
						
					},function(err){
						if(flag==true){

							eacharticle.match=rangesite(compte,this_match);
							all_NonReF.push(eacharticle);
						}
												
						cb_docs(err);

					});
				},function(err){
					callback(null,null)
				});
			}
			else{
				callback(null,null);
			}
		}
	],function(err){
		
		cb(err,all_NonReF);
	})

}


module.exports.agg_alert=agg_alert;
module.exports.agg_nv=agg_nv;
module.exports.agg_non_refresh=agg_non_refresh;
