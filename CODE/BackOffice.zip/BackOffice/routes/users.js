var ua=require("universal-analytics");
var express = require('express');
var router = express.Router();

var async = require('async')
 , mongojs = require('mongojs')
 , ObjectId = mongojs.ObjectId
 , _ = require('underscore')
 , exec = require('child_process').exec;

var db_admin = require("./DB/db_admin_con");

var ADMIN=db_admin.collection("admin");
var RP=db_admin.collection("rapport_proxy");

router.get('/:name/:password',function(req,res){
	var name=req.params.name;
	var password=req.params.password;	
	
	ADMIN.findOne({login:name,password:password},function(err,docs){
		
		
		if(docs!=null){
			//var visitor = ua('UA-45861589-3', docs._id.toString());		
			//visitor.pageview("/login").send();
			res.jsonp({ok:1, docs:docs});
		}
		else{
			res.jsonp({ok : 0});
		}
		
	});
	
 });
 
router.get('/info', function (req, res) {
	var iduser=ObjectId(req.query.user);

	ADMIN.findOne({_id:iduser},function(err,docs){
		res.jsonp(docs);
	});
});

router.post('/getproxy',function(req,res){
	var iduser=ObjectId(req.body.user);

	ADMIN.findOne({_id:iduser},{proxy_list:1},function(err,docs){
		res.jsonp(docs);
	});
});

router.post('/putproxy',function(req,res){
	var iduser=ObjectId(req.body.user);
	var ip=req.body.ip;
	var comment=req.body.comment;

	ADMIN.update({_id:iduser},{$addToSet:{proxy_list:{ip:ip,comment:comment}}},function(err,docs){
		res.jsonp(err);
	});
});

router.post('/deleteproxy',function(req,res){
	var iduser=ObjectId(req.body.user);
	var ip=req.body.ip;

	ADMIN.update({_id:iduser},{$pull:{proxy_list:{ip:ip}}},function(err,docs){
		res.jsonp(err);
	});
});

router.post('/getrapport',function(req,res){
	var now=new Date();
	var today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
	
	RP.find({time:{"$gt":today}},function(err,docs){
		res.jsonp(docs);
	});
});


module.exports = router;
