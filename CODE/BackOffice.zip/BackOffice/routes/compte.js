var express = require('express');
var router = express.Router();

var async = require('async')
 , mongojs = require('mongojs')
 , ObjectId = mongojs.ObjectId
 , _ = require('underscore')
 , exec = require('child_process').exec;

var db = require("./DB/db_con");

var COMPTE=db.collection("compte");
var USER=db.collection("user");
var SITES=db.collection("sites");

router.post('/sites',function(req,res){
	 
	var site_name = req.body.site_name;

	async.waterfall([
		function(callback)
		{
			COMPTE.findOne({site_name:site_name},function(err,docs){
				callback(null, docs);
			});	
					
		},
		function(compte, callback){

            var result = [];
            async.forEachSeries(compte.site,function(eachsiteid,cb_docs){

				SITES.findOne({_id:eachsiteid},function(err,docs){
					result.push(docs);
					cb_docs(err);
				});
											
			},function(err)
			{
				callback(err,result);
			});

		}
	], function (err, result) {
		res.jsonp(result);
	});
});

router.post('/all_compte',function(req,res){

	COMPTE.find({},function(err,docs){
		
		async.forEach(docs,function(eachcompte,cb_docs){
			
			var sites=[];
			async.forEach(eachcompte.site,function(eachsiteid,cb_docs2){
				SITES.findOne({_id:ObjectId(eachsiteid)},{name:1},function(err,docs){
					sites.push(docs.name);
					cb_docs2(err);
				});
			},function(err){
				eachcompte.site=sites;
				cb_docs(err);
			});
										
		},function(err){
			//console.log(docs);
			res.jsonp(docs);
		});		
	});	

});

router.post('/all_user',function(req,res){

	USER.find({},function(err,docs){
		
		async.forEach(docs,function(eachuser,cb_docs){

			COMPTE.findOne({_id:ObjectId(eachuser.compte_id)},{site_name:1},function(err,docs2){
				eachuser.compte_name=docs2.site_name;
				cb_docs(err);
			});

										
		},function(err){
			res.jsonp(docs);
		});		
	});	

});

router.post('/add_user',function(req,res){
	var NewUser= Object.create(null);
	NewUser.login=req.body.username;
	NewUser.password=req.body.pwd;
	NewUser.compte_id=ObjectId(req.body.compte_id);
	
	NewUser.lang={
		"sign" : "FR-FR",
		"name" : "Français"
	};
	NewUser.pages={
		"reactivity" : 5,
		"listing" : 5
	};
	
	USER.save(NewUser,function(err,docs){

		COMPTE.findOne({_id:ObjectId(docs.compte_id)},{site_name:1},function(err,docs2){
			docs.compte_name=docs2.site_name;
			res.jsonp(docs);
		});		
		

	});
});

router.post('/delete_user',function(req,res){
	var user_id=ObjectId(req.body.user_id);
	
	USER.remove({_id:user_id},function(err,docs){
		res.jsonp(docs);
	});
});

router.post('/add_compte',function(req,res){
	var NewCompte= Object.create(null);
	NewCompte.site_name=req.body.site_name;
	NewCompte.cat_gen=[];
	NewCompte.module=req.body.module;
	
	NewCompte.site=[];
	
	for(var i=0;i<req.body.site.length;i++){
		NewCompte.site.push(ObjectId(req.body.site[i]._id));
	}
	
	NewCompte.site_WASA=[];
	NewCompte.site_PERF=[];
	
	if(req.body.module.WASA==true){
		for(var i=0;i<req.body.site_WASA.length;i++){
			NewCompte.site_WASA.push(ObjectId(req.body.site_WASA[i]._id));
		}
	}
	if(req.body.module.PERF==true){
		for(var i=0;i<req.body.site_PERF.length;i++){
			NewCompte.site_PERF.push(ObjectId(req.body.site_PERF[i]._id));
		}
	}	
	
	NewCompte.update=[
        {
            "version" : "6.0",
            "date" : "11/03/2015",
            "change" : [ 
                "Nouvelle affichage modulaire incluant SPE", 
                "Traduction multilingue", 
                "Nouveau Tableau de Bord avec Statistiques"
            ]
        }
    ];
    
    if(req.body.supplier=="true"){
		NewCompte.notice={
			"good" : 0,
			"bad" : 0,
			"pire" : 0
		};
		NewCompte.supplier=true;
	}
	else{
		NewCompte.notice={
			"react" : 0
		};
		NewCompte.supplier=false;
	}
	
	SITES.save({name:req.body.site_name, url:""},function(err,docs){
		
		NewCompte.site_id=docs._id;
		
		COMPTE.save(NewCompte,function(err,docs2){
			res.jsonp(docs2);
		});		
		

	});
});

router.post('/delete_compte',function(req,res){
	var compte_id=ObjectId(req.body.compte_id);
	
	COMPTE.remove({_id:compte_id},function(err,docs){
		res.jsonp(docs);
	});
});

router.post('/getallsite',function(req,res){
	SITES.find({},function(err,docs){
		res.jsonp(docs);
	});
});

router.post('/add_site',function(req,res){
	var NewSite= Object.create(null);
	NewSite.name=req.body.name;
	NewSite.url=req.body.url;
	NewSite.color=req.body.color;
	
	SITES.save(NewSite,function(err,docs){
		res.jsonp(docs);
	});
});

router.post('/update_site',function(req,res){
	var site_id=ObjectId(req.body.site_id);
	
	SITES.update({_id:site_id},{name:req.body.name, url:req.body.url, color:req.body.color},function(err,docs){
		res.jsonp(docs);
	});
});

router.post('/delete_site',function(req,res){
	var site_id=ObjectId(req.body.site_id);
	
	SITES.remove({_id:site_id},function(err,docs){
		res.jsonp(docs);
	});
});

module.exports = router;
