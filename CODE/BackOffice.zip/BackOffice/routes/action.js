var express = require('express');
var router = express.Router();

var async = require('async')
 , mongojs = require('mongojs')
 , ObjectId = mongojs.ObjectId
 , _ = require('underscore')
 , exec = require('child_process').exec;

var db = require("./DB/db_con");

var STA_AQU=db.collection("Statistique_aqualung");
var COMPTE=db.collection("compte");
var SITES=db.collection("sites");

var MID_PRICE = require("./DB/mid_price");


router.post('/price_test', function (req, res) {

	var site=req.body.site;
	var url=req.body.url;
	
	var proxy_type=req.body.proxy_type;
	var proxy_addr=req.body.proxy_addr;

		
	MID_PRICE.getprice(site,url,proxy_type,proxy_addr,function(err,result){					
		
		res.jsonp(result);
		
	});

});

router.post('/price_refresh', function (req, res) {
	
	var compte_name = req.body.compte_name;
	
	var article_id=ObjectId(req.body.article_id);
	var product_id=ObjectId(req.body.product_id);
	var site_id=ObjectId(req.body.site_id);
	var url=req.body.url;
	
	var proxy_type=req.body.proxy_type;
	var proxy_addr=req.body.proxy_addr;

	
	async.waterfall([
	
		function(callback){
			SITES.findOne({_id:site_id},callback);			
		},
		function(site, callback)
		{
			COMPTE.findOne({site_name:compte_name},function(err,compte){
				var ARTICLES=db.collection("articles_"+compte.site_name);
				var PH=db.collection("priceHistory_"+compte.site_name);
				
				MID_PRICE.getprice(site.name,url,proxy_type,proxy_addr,function(err,result){
								
					result.NV_bell=false;
					
					MID_PRICE.after_getprice_modify(ARTICLES,PH,article_id,result,function(err){

						callback(null,result);
					});

				});
			});
			
		}
	],function(err,result){
		
		res.jsonp(result);
	});
});


router.post('/price_modifyUrl', function(req,res){

	var url = req.body.url;		
	var compte_name = req.body.compte_name;

	//var img_path="no_change";
	
	var article_id=ObjectId(req.body.article_id);		
	var site_id=ObjectId(req.body.site_id);

	var proxy_type=req.body.proxy_type;
	var proxy_addr=req.body.proxy_addr;
	
	async.waterfall([        
		function(callback){
			SITES.findOne({_id:site_id},callback);
		},
		function(site,callback){
				
			var sitename=site.name;
		
			MID_PRICE.getprice(sitename,url,proxy_type,proxy_addr,function(err,result){		

				COMPTE.findOne({site_name:compte_name},function(err,compte){
					var PH=db.collection("priceHistory_"+compte.site_name);
					var ARTICLES=db.collection("articles_"+compte.site_name);	
			
					ARTICLES.update({_id:article_id},{$set:{url:url}},function(err){				
						result.NV_bell=false;		
						
						MID_PRICE.after_getprice_modify(ARTICLES,PH,article_id,result,callback);					

					});
				});
			});		
		}
		
	], function (err, ARTICLES) {

		ARTICLES.findOne({_id:article_id},function(err,data){
			data.site=data.site._id;
			res.jsonp(data);
		});
	});
});


router.post('/regenerer',function(req,res){
	
	async.waterfall([
		function(callback){
				var now=new Date();
				var today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
				
				STA_AQU.remove({"date":today},callback);
		},
		function(docs,callback){
			//var file_path="/home/mao/workspace/final3/robot/sta_his.js";
			var file_path="/root/BSWEB/SPE/v6/comparator-api/robot/sta_his.js";
			exec("node "+file_path,function(err,stdout,stderr){	
				  console.log(stdout);
				  console.log(err);
				  console.log(stderr);
							
				  callback(err,"success");

			 });	
		}
	],function(err){
		res.send("ok");
	});
	
	
});

router.post('/reenvoyer',function(req,res){
	
	async.waterfall([
		function(callback){
			//var file_path="/home/mao/workspace/final3/robot/crontab/mail/rapport_alert.php";
			var file_path="/root/BSWEB/SPE/v6/comparator-api/robot/crontab/mail/rapport_alert.php";
			exec("php "+file_path,function(err,stdout,stderr){	
				  console.log(stdout);
				  console.log(err);
				  console.log(stderr);
							
				  callback(err,"mail_alert:ok");

			 });	
		},
		function(docs,callback){
			//var file_path="/home/mao/workspace/final3/robot/crontab/mail_node/mail_aqualung.js";
			var file_path="/root/BSWEB/SPE/v6/comparator-api/robot/crontab/mail_node/mail_aqualung.js";
			exec("node "+file_path,function(err,stdout,stderr){	
				  console.log(stdout);
				  console.log(err);
				  console.log(stderr);
							
				  callback(err,docs+"mail_aqualung:ok");

			 });	
		}
	],function(err,docs){
		res.send(docs);
	});
	
	
});

module.exports = router;
