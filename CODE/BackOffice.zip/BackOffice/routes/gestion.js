var express = require('express');
var router = express.Router();

var async = require('async')
 , mongojs = require('mongojs')
 , ObjectId = mongojs.ObjectId
 , _ = require('underscore')
 , exec = require('child_process').exec;

var db = require("./DB/db_con");
var DB_AGG = require("./DB/db_follow_agg");

var STA_AQU=db.collection("Statistique_aqualung");
var COMPTE=db.collection("compte");

router.post('/nv', function (req, res) {
	
	var sitename=req.body.user_name;
	
	COMPTE.findOne({site_name:sitename},function(err,compte){
		DB_AGG.agg_nv(compte._id, compte.site_name,function(err,docs){
			
			res.jsonp(docs);
			
		});
	});
});

router.post('/alert', function (req, res) {
	
	var sitename=req.body.user_name;
	
	COMPTE.findOne({site_name:sitename},function(err,compte){
		DB_AGG.agg_alert(compte,function(err,docs){
			
			res.jsonp(docs);
			
		});
	});
});

router.post('/non_refresh', function (req, res) {
	
	var sitename=req.body.user_name;
	
	COMPTE.findOne({site_name:sitename},function(err,compte){
		DB_AGG.agg_non_refresh(compte,function(err,docs){
			
			res.jsonp(docs);
			
		});
	});
});
 
router.post('/sta_aqu',function(req,res){
	
	var now=new Date();
	var today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
	
	STA_AQU.findOne({"date":today},function(err,docs){
		
		if(docs!=null){
			res.jsonp({last_time :docs.time_insert});
		}
		else{
			res.jsonp({last_time :"error"});
		}
	});
	
});

module.exports = router;
