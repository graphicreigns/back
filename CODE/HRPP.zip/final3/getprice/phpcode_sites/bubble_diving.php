<?php
if (strcmp($site['name'], 'Bubble-Diving') == 0)// Parsing du prix de l'article pour le site Bubble-Diving
{
	$flag_site_php=true;
	
	if($prixArticleStr = $html->find('#table_mm_nd_grid .price', 0)){
		$prixArticleStr = $prixArticleStr->plaintext;
		if(strpos($prixArticleStr,".")>0)
		{
			$prixArticle =  floatval(str_replace(array(',', ' '),array('', ''),$prixArticleStr));
		}		
		else
		{
			$prixArticle =  floatval(str_replace(array(',', ' '),array('.', ''),$prixArticleStr));
		}
		createUpdateArray($site['name'], $prixArticle);
	}			
	elseif($prixArticleStr = $html->find('.product-essential .special-price .price', 0)){
		$prixArticleStr = htmlentities($prixArticleStr->plaintext, null, 'utf-8');
		$prixArticle =  floatval(str_replace(array(',', "/\s/","&nbsp;"),array('.', '', ''),$prixArticleStr));
		createUpdateArray($site['name'], $prixArticle);
	}
	else{//sinon le prix regular
		if($prixArticleStr = $html->find('.product-essential .regular-price', 0)){
			$prixArticleStr = htmlentities($prixArticleStr->plaintext, null, 'utf-8');
			echo $prixArticleStr;
			$prixArticle =  floatval(str_replace(array(',', "/\s/", "&nbsp;"),array('.', '', ''),$prixArticleStr));
			createUpdateArray($site['name'], $prixArticle);
		}else{//il n'y a pas de prix
			$prixArticle = -2;
			createUpdateArray($site['name'], $prixArticle);
		}
	}
	
}



?>
