<?php
if (strcmp($site['name'], 'VieuxPlongeur') == 0)// Parsing du prix de l'article pour le site VieuxPlongeur
{
	$flag_site_php=true;
	
	if($prixArticleStr = $html->find('.our_price_display', 0)){
		$prixArticleStr = $prixArticleStr->plaintext;
		$prixArticle = floatval(str_replace(array(',', ' '),array('.', ''),$prixArticleStr));
		createUpdateArray($site['name'], $prixArticle);
	}
	else{
		$prixArticle = -2;
		createUpdateArray($site['name'], $prixArticle);
	}
}
?>
