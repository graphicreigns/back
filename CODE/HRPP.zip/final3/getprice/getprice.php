<?php
include('simplehtmldom_1_5/simple_html_dom.php');

	function createUpdateArray($sitename,$price)
	{
		echo '{"html":false,"img_url":"","price":'.$price.',"stock":"","sitename":"'.$sitename.'"}';

	}

	/*permet de vérifier l'existance d'une url*/
	function url_exists($url){
		if ((strpos($url, "http")) === false) $url = "http://" . $url;
		$headers = @get_headers($url);
		if (is_array($headers)){
			//Check for http error here....should add checks for other errors too...
			if(stripos($headers[0], '404')){
				return false;
			}
			else{
				return true;
			}
		}
		else
		 	return false;
	}


$url = $argv[1];
$site['name'] = $argv[2];

$site_model1=array("Recif_Art","Botanic","Aqua_store","Medoretcie","Aquastory","Poisson_Or","LeGrandBleu","AchatAquarium");

$site_model=array("Akouashop","MedicAnimal","BleuAquarium","Aqua2004");
$site_mot_cle=array("Akouashop"=>".price-cur","MedicAnimal"=>"#price","BleuAquarium"=>".product-price","Aqua2004"=>"#prcIsum");


$curl = curl_init(); 
curl_setopt($curl, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
curl_setopt($curl, CURLOPT_PROXY, '127.0.0.1:9050');
curl_setopt($curl, CURLOPT_URL, $url);  
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);  
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);  
$str = curl_exec($curl);  
curl_close($curl);  
 



//if(url_exists($url)){
	//$html = file_get_html($url, false, $context); // @ pour ne pas lire les erreur de cette fonction (qui bloque le reste du script) 
	$html= str_get_html($str);
	echo $html;
	if (!($html && is_object($html))) {

		$prixArticle = -2;
		createUpdateArray("html non existe",$prixArticle);

		exit;
	}
/*}
else{
	$prixArticle = -2;
	createUpdateArray("url not exist",$prixArticle);
	exit;
}*/

$flag_site_php=false;

//*************include all files dans phpcode_sites
$dir=dirname(__FILE__)."/phpcode_sites/";			
$handle=opendir($dir.".");
$array_file = array();
while (false !== ($file = readdir($handle)))
{
	if ($file != "." && $file != "..") {
		include 'phpcode_sites/'.$file;			
	}
}
closedir($handle);
//*********************************	

if ($flag_site_php==false)
{
	$prixArticle = -2;
	createUpdateArray("Magasin non trouve",$prixArticle);
}

$html->clear(); 
unset($html);

?>
