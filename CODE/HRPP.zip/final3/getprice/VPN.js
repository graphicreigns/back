var page = require('webpage').create();
var system = require('system');
var url;

if (system.args.length === 1) {
    console.log('Usage: loadspeed.js <some URL>');
    phantom.exit(1);
} else {
	url = system.args[1];

page.settings.userAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko)';
	
	page.open(url, function() {	
				
		//console.log(url);
		page.evaluate(function() {
			setLocation(document.getElementById('enigm_shipping_country').children[67].getAttribute('onclick').slice(13,-2));	
		});		
		
		window.setTimeout(function () {

			var truc=page.evaluate(function() {

				var return_price_value="-2";
				var return_stock_value="";
				var return_html_value=false;
				

				
				var stock_table={"En stock":"en stock", "Disponible sous 10 jours":"+5 jours"};
				var return_price=  document.getElementsByClassName("mm_nd_grid"); 


				if(return_price.length==0){
					if(document.getElementsByClassName("product-asw").length>0){
						return_price= document.getElementsByClassName("product-price")[0].getElementsByTagName("span");  
						
						if(return_price.length>0){
							for(var i=0;i<return_price.length;i++){
								if(return_price[i].id.indexOf("product-price")==0){
									return_price_value=return_price[i].textContent;
								}
							}
						}
						return_stock_value=stock_table[document.getElementsByClassName("product-asw")[0].children[0].textContent];
					}
				}
				else{
					return_html=document.getElementsByClassName("mm_nd_grid")[0];
		
					var nb_col=return_html.rows[0].cells.length;
					var stockage={"En stock":2,"Disponible sous 10 jours":1,"rupture":0};	
					var return_stockage=["rupture","+5 jours","en stock"];
					var meilleur_stock=0;	   //le plus gros, le plus en stock
					
					if(return_html.rows.length>1){
					
						var price=return_html.rows[1].cells[nb_col-2].textContent;				
							price=price.replace(/(^\s*)|(\s*$)/g, "");  //delete space
							price=price.replace('€',"").replace(',',"");						
						var meilleur_prix=parseFloat(price);

						for(var i=0;i<return_html.rows.length;i++){
							
							return_html.rows[i].deleteCell(nb_col-1);
							
							if(i>0){
								price=return_html.rows[i].cells[nb_col-2].textContent;				
								price=price.replace(/(^\s*)|(\s*$)/g, "");  //delete space
								price=price.replace('€',"").replace(',',"");						
								
								if(parseFloat(price)<meilleur_prix)	 meilleur_prix=parseFloat(price);
								
								if(stockage[return_html.rows[i].cells[nb_col-3].textContent]>meilleur_stock){
									meilleur_stock=stockage[return_html.rows[i].cells[nb_col-3].textContent];
								}
															
							}
						}
						
						return_price_value=""+meilleur_prix+"";			
						return_stock_value=return_stockage[meilleur_stock];
						return_html_value=return_html.outerHTML;
					}
				}

				if(return_price_value.indexOf('$')>0)  return_price_value="-2";
				
				
				  return {
						  price: parseFloat(return_price_value.replace(/\s*/g, "").replace('€',"").replace(',',".")),
						  stock: return_stock_value,
						  html: return_html_value,
						  img_url: ""
						 }; 
			});
			console.log("string begins here:");
			console.log(JSON.stringify(truc));
		
			phantom.exit();
        }, 2000);
				
	});
}
