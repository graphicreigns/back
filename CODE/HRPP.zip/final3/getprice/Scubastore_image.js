var phantom = require('phantom');

process.on('message', function(msg) {
	
	console.log('CHILD got message:', msg.url);
	
 	phantom.create(function (ph) {
		ph.createPage(function (page) {
			page.open(msg.url, function (status) {
				
			  page.evaluate(function () { 
				  
				//price  
				var return_price_value="-2";
				var return_price= document.getElementById("total_dinamic");  
				var return_image_url="";
				
				var host=location.hostname;	
				
				if(host.indexOf("scubastore")!=-1){
				
				
					if(return_price!=null){
						return_price_value=return_price.textContent;
					}
					
					//url_img
					var return_img=document.getElementById("thumImg").getElementsByTagName("a");
					var return_image_url=return_img[0].getAttribute("data-image");
				  
				}	
					
				  return {
						  price: return_price_value,
				          stock: "en stock",
				          img_url: return_image_url
				         }; 
				  
			  }, function (result) {
				   
					price=result.price.replace(/(^\s*)|(\s*$)/g, "");  //delete space
					price=price.replace('€',"");				
					
					if(isNaN(price)) price="-2";
					if(parseFloat(price)==0) price="-2";
					console.log('Price is ' + price);
					
					//console.log(result.img_url);
					process.send({ price: parseFloat(price), stock: "", html:false, img_url:result.img_url});
					process.exit();
			  });				
				
	
				
			});
		});
	});
	
});
