var exec = require('child_process').exec;
var path = require('path');

process.on('message', function(msg) {
	
	console.log('CHILD got message:', msg.url);	
	var file_path=path.resolve(__dirname);

	console.log("php "+file_path+"/getprice.php "+msg.url+" VieuxPlongeur");
	
	 exec("php "+file_path+"/getprice.php "+msg.url+" VieuxPlongeur",function(err,stdout,stderr){
		  console.log(stdout);
		  //console.log(err);
		  //console.log(stderr);
		 /* if (err) return callback(err);
		  if (stderr) return callback(stderr);
		  if (parseInt(stdout) == 1) callback(null,1);
		  else callback(null,0);*/
			
			process.send(JSON.parse(stdout));
			process.exit();
					
			
	  });	
});
