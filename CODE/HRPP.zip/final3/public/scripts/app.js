
  'use strict';
   var APP=angular.module('app', ['n3-charts.linechart','ngCookies','ngRoute','ngSanitize', 'ngAnimate', 'ui.bootstrap', 'easypiechart', 'mgo-angular-wizard', 'textAngular', 'angular-loading-bar', 'app.ui.ctrls', 'app.ui.directives', 'app.ui.services', 'app.controllers', 'app.directives', 'app.form.validation', 'app.ui.form.ctrls', 'app.ui.form.directives', 'app.tables', 'app.task', 'app.localization', 'app.chart.ctrls', 'app.chart.directives']).config([
    '$routeProvider', function($routeProvider) {
     $routeProvider.when('/', {
        redirectTo: '/pages/signin'
      }).when('/dashboard', {
        templateUrl: 'views/perf.html'
      }).when('/web', {
        templateUrl: 'views/moduleWeb.html'
      }).when('/mail', {
        templateUrl: 'views/mail.html'
      }).when('/wasa', {
        templateUrl: 'views/wasa.html'
      }).when('/spe/statistique', {
        templateUrl: 'views/statistique.html'
      }).when('/spe/reactivite', {
        templateUrl: 'views/spe/reactivite_frame.html'
      }).when('/spe/listing', {
        templateUrl: 'views/spe/listing_frame.html'
      }).when('/spe/archive', {
        templateUrl: 'views/spe/archive_frame.html'
      }).when('/pages/signin', {
        templateUrl: 'views/pages/signin.html',
        controller: 'LoginCtrl'
      }).when('/404', {
        templateUrl: 'views/pages/404.html'
      }).when('/pages/500', {
        templateUrl: 'views/pages/500.html'
      }).when('/pages/blank', {
        templateUrl: 'views/pages/blank.html'
      }).when('/pages/invoice', {
        templateUrl: 'views/pages/invoice.html'
      }).when('/tasks', {
        templateUrl: 'views/tasks/tasks.html'
      }).otherwise({
        redirectTo: '/404'
      });
    }
  ]).factory('_', function() {
	return window._; // assumes underscore has already been loaded on the page
  }).factory('getcookie', function(){
	  
	return function(data,lang){
		var e = document.getElementById('app_ctrl');
		var scope = angular.element(e).scope();
	   
		scope.main.name=data.site_name;
		scope.main.url_logo=data.url_img;
		scope.main.update=data.update;
		scope.main.notice=data.notice;
		scope.main.supplier=data.supplier;
				
		angular.element(document.getElementById('lang_ctrl')).scope().lang=lang.name;
	}
  }).run(function ($rootScope, $cookieStore, $location) {
        $rootScope.$on("$routeChangeStart", function (event, next, current) {

            if ($cookieStore.get('userID') == undefined) {
				
				$location.path("/pages/signin");

            }
            
        });
    });
