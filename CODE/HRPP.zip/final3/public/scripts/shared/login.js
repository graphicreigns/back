
APP.controller('LoginCtrl', ['$scope', '$location', '$cookieStore', '$rootScope', '$http','localize','getcookie', function ($scope, $location, $cookieStore, $rootScope, $http, localize,getcookie) {

    $rootScope.page = "login";

    var logout = function logout() {
        $cookieStore.remove('userID');
        $cookieStore.remove('supplier');
        $cookieStore.remove('lang');

		/*var child=document.getElementById("chat");
		if(child!=null){
			window.location.reload();
		}*/
    }; logout();

    $scope.checkLogin = function () {
		
		$scope.user=$("#user-tf").val();
		$scope.pass=$("#pass-tf").val();
		
        $http.get('/user/'+$scope.user+'/'+$scope.pass).success(function(data) {
			
               if (data.ok == 1)
               {
                   $cookieStore.put('userID', data.docs._id);
                   	$cookieStore.put('compteID', data.docs.compte_id);
                   $cookieStore.put('lang',data.docs.lang.sign);
                   
                    localize.setLanguage(data.docs.lang.sign);
                    
                    $http.get('/user/getCompte?idcompte='+data.docs.compte_id).success(function(data2) {
						$cookieStore.put('supplier',data2.supplier);
						getcookie(data2,data.docs.lang);
						$location.path("/dashboard");
					});
                    

	
                   
                   /*if(data.login=="aqualung"){
						var s = document.createElement('script'); // use global document since Angular's $document is weak
						s.id = 'chat';
						s.src='scripts/chat_aqu.js';
						document.body.appendChild(s);
				   }*/
                   


               }
                else{
                   alert('Combinaison invalide');
               }
            });
    };
    
}]);
