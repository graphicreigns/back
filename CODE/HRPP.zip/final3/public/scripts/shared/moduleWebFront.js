APP.controller("moduleWebCtrl",  ['$scope', '$http', '$sce', function ($scope, $http,$sce) {

	
	$scope.sites = [
		$sce.trustAsResourceUrl("http://www.palanquee.com"),
		$sce.trustAsResourceUrl("https://www.mares.com/"),
		$sce.trustAsResourceUrl("http://www.aqualung.com/fr/"),
		$sce.trustAsResourceUrl("http://www.bubble-diving.com")
	];
	
	$scope.shownSite = "";
	
	$scope.showingSite = function(){
		return $scope.shownSite != "";
	};
	
	$scope.showSite = function(site){
		$scope.shownSite = site;
	};
	
	$scope.goBack = function(){
		$scope.showSite("");
	};
	
}]);
