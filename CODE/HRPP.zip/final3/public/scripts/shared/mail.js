APP.controller("moduleMailCtrl",  ['$scope', '$http', '$modal', function ($scope, $http, $modal) {


	

	$scope.error = "";
	$scope.emails = [];
	$scope.showedMail = "";
	
	$scope.waitModal = undefined;
	
	$scope.openWaitModal = function(){
		 return $modal.open({
			templateUrl:"waitModal.html",
			size: 'sm'			
		});
	};
	
	$scope.goToMailbox = function(){
		$scope.waitModal = $scope.openWaitModal();
		$scope.error = "";
		$http.get("/moduleMail").success(function(data){
		
			$scope.waitModal.close();
			
			$scope.emails = data;
			console.log(data);
		}).error(function(data){
			$scope.error = data;
		});
	};
	
	$scope.stringToDate = function(mydate){
		return new Date(mydate);
	};
	
	$scope.displayMail = function(mail){
		$scope.showedMail=mail;
	};
	
	$scope.backToMails = function(){
		$scope.showedMail = "";
	};
	
	$scope.showingMail = function(){
		return $scope.showedMail != "";
	};
	
	$scope.goToMailbox();
	
}]);
