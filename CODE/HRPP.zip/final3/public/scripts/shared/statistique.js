APP.controller('StatisticCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize','$location', function ($scope, $location, $cookieStore, $http, $modal, localize,$location) {

	$scope.user = $cookieStore.get('userID');
	$scope.compte = $cookieStore.get('compteID');
	$scope.supplier = $cookieStore.get("supplier");

	$scope.title="Statistiques";
    $scope.flag_roue=true;
	$scope.num_refresh_total=0;
	$scope.num_refresh_done=0;
	$scope.data=[];
	$scope.exec_flag=true;	
	
	$scope.index_sel=-1;
	$scope.legend_detail="";
	$scope.flag_show_details=false;
	
	
	$scope.show="all";
	$scope.zld=false;
	$scope.sites=[];
	//$scope.categories=[];

	$scope.vide={total:0,bad:0};
	$scope.num_all={total:0,bad:0};
	$scope.frameUrl="#";
	
	$scope.today=new Date();
	$scope.dt2=$scope.today.getTime();
	$scope.dt1=$scope.dt2-604800000;
	
	$scope.type_show=[
		{"type":"all","title_long":"Pourcentage de prix non respectés","title_short":"Total prix non respectés","img_big":"type1_big.jpg","img_small":"type1_small.jpg","choisi":"oui"},
		{"type":"cat","title_long":"Pourcentage de produits non respectés par catégorie","title_short":"Catégories les moins respectées","img_big":"type2_big.jpg","img_small":"type2_small.jpg","choisi":"non"},
		{"type":"site","title_long":"Pourcentage de produits non respectés par rapport au nombre de produits vendus","title_short":"Sites les moins respectueux","img_big":"type3_big.jpg","img_small":"type3_small.jpg","choisi":"non"},
		{"type":"pire","title_long":"Pourcentage de prix les plus bas par rapport au nombre de produits vendus","title_short":"Sites avec prix les plus bas","img_big":"type4_big.jpg","img_small":"type4_small.jpg","choisi":"non"}
	];
	
	$scope.do_change=function(){
		$scope.flag_show_details=false;
		if($scope.show=="pire"){
			$scope.frameUrl_sta="views/pages_include/sta_chat2.html?compte="+$scope.compte+"&date="+$scope.dt2;			
		}
		else{
			$scope.frameUrl_sta="views/pages_include/sta_chat.html?compte="+$scope.compte+"&date_start="+$scope.dt1+"&date_end="+$scope.dt2+"&zld="+$scope.zld+"&type="+$scope.show;
		}
	};

	$scope.setchoisi=function(each_type){
		
        var modalInstance= $modal.open({
          templateUrl: "myModalContent.html",
          controller: 'ModalInstanceCtrl',
          resolve: {
            type_show: function() {
              return each_type;
            }
          }
        });
        modalInstance.result.then(function(date_recu) {
			$scope.dt1 = date_recu.dt1;
			$scope.dt2 = date_recu.dt2;
			_.find($scope.type_show,{choisi:"oui"}).choisi="non";
			each_type.choisi="oui";	
			$scope.show=each_type.type;	          
			$scope.do_change();

        });
		

	}
	
	$scope.get_choisi=function(){
		return _.find($scope.type_show,{choisi:"oui"});
	}

	$scope.print=function(){

		var data_img=document.getElementById("download").href

		var html= '<html><span> <img src="images/'+$scope.get_choisi().img_small+'"></span> '+
				 '<span class="lead"> <b> &nbsp;&nbsp;'+$scope.get_choisi().title_short+'</b></span>'+  
				'<p><img src="' + data_img + '"></p>'+
				'<script>window.print()</script>';						
		
		var mywindow=window.open("","_blank");
		mywindow.document.write(html);

	}
	
	$scope.get_imagedata=function(){

		var data_img=$("#this_frame").contents().find("input")[0].value;
		return data_img;
	}

	$scope.setbg=function(value){
		var str="";
		if(value.max_min=="max") str="color : red";
		if(value.max_min=="min") str="color : green";
		return str;
	};
	
	$scope.set_sel=function(index,value){
		if(value.change=="aug") return "background-color : LightGreen";
		if(value.change=="dim") return "background-color : LightCoral";
		if(index==$scope.index_sel) return "background-color: lightyellow";
	};

	$scope.goToProductPage = function(article) {
		if(article.url!=""){
			window.open(article.url);
		}
	}; 

    $scope.show_details=function(legend1,legend2,array_details,index,date){
		$scope.flag_show_details=true;
		$scope.index_sel=index;
		$scope.data=[];
		$scope.num_refresh_total=array_details.length;
		$scope.legend_detail=legend1+" "+legend2;
		if($scope.num_refresh_total>0){
	
			var waitmodalInstance =$modal.open({
				templateUrl:"waitModal.html",
				scope: $scope,
				size: 'sm'			
			});

	
			$scope.myVar=setInterval(function () {
					console.log("interval continues");
					if($scope.exec_flag==true){
										
						$scope.exec_flag=false;
						
						$http.jsonp('/articles/getline?compte='+$scope.compte+'&product_id='+array_details[$scope.num_refresh_done]+'&date='+date+'&callback=JSON_CALLBACK').success(function(data){
							$scope.num_refresh_done++;
							$scope.exec_flag=true;
							$scope.data.push(data);
							
							if($scope.num_refresh_done>=$scope.num_refresh_total){
								clearInterval($scope.myVar);
								$scope.num_refresh_done=0;
								waitmodalInstance.close();
							}

						}).error(function(data, status, headers, config) {
							clearInterval($scope.myVar);
							alert("Erreur");
						});				
					
					}
				
				
			}, 10);
		}
		else{
			$scope.num_refresh_done=0;
			$scope.num_refresh_total=0;
		}
		
		
	};	

    $scope.get_mail=function(str_date,text_trans){
		
		$scope.index_sel=-1;
				
		var date=new Date(str_date);
		var date_moins1=new Date(date.getFullYear(),date.getMonth(),date.getDate()-1);
		var date_affiche=date.getDate()+"/"+(date.getMonth()+1)+"/"+date.getFullYear();
		var date_moins1_affiche=date_moins1.getDate()+"/"+(date_moins1.getMonth()+1)+"/"+date_moins1.getFullYear();
		
		$scope.legend_detail="Les changements entre le "+date_moins1_affiche+" et le "+date_affiche;
		
		$http.jsonp('/articles/getmail?compte='+$scope.compte+'&date='+date.getTime()+'&callback=JSON_CALLBACK').success(function(data){
			
			if(data.length>0){
				var r=confirm("Voulez-vous afficher les changements entre le "+date_moins1_affiche+" et le "+date_affiche+" "+text_trans);
				if (r==true){
					$scope.data=data;
					$scope.num_refresh_total=data.length;					
					$scope.flag_show_details=true;						
				}
			}
			else{
				alert("Il n'y a pas de changement entre le "+date_moins1_affiche+" et le "+date_affiche+" "+text_trans);
			}

		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});			
				
	};	

	$scope.loadChart=function(product){
		var param=product._id;
		
		if($scope.supplier==true){
			var RRP=parseFloat($scope.data.marge)-(parseFloat($scope.data.marge)*parseFloat($scope.data.percentage)/100)
			$scope.frameUrl="views/spe/partie_frame/views/modal/frame.html?compte="+$scope.compte+"&FA_id="+param+"&archive=false&RRP="+RRP;
		}
		else{
			$scope.frameUrl="views/spe/partie_frame/views/modal/frame.html?compte="+$scope.compte+"&FA_id="+param+"&archive=false";			
		}		
		$scope.waitmodalInstance =$modal.open({
			templateUrl:"graph.html",
			scope: $scope,
			size:'lg'			
		});			
		
	};

    $scope.cancel = function () {
		$scope.waitmodalInstance.dismiss('cancel');
	};

	$http.jsonp('/user/sites?compte='+$scope.compte+'&callback=JSON_CALLBACK').success(function(data){
		$scope.sites = data;
	});

	
	if($scope.supplier==true){
		$scope.do_change();
	}
	else{
		$scope.type_show=[{"title_long":"Performance sur prix les plus bas","title_short":"Performance sur prix les plus bas","img_big":"type4_big.jpg","img_small":"type4_small.jpg","choisi":"oui"}];
		$scope.frameUrl_sta="views/pages_include/sta_chat_retailer.html?compte="+$scope.compte;
	}
}])

.controller('ModalInstanceCtrl', ['$scope', '$modalInstance', 'type_show', function($scope, $modalInstance, type_show) {
      
		if(type_show.type=="pire"){
			$scope.this_radio="option3";
			$scope.title="Choisir la date";
			$scope.disable_this=true;
		}
		else{
			$scope.title="Choisir la période";			
			$scope.this_radio="option1";
			$scope.disable_this=false;			
		}
		$scope.date_envoie={};
		
		$scope.today=new Date();
		$scope.date_envoie.dt2=$scope.today.getTime();


		$scope.ok = function() {
			
			if($scope.this_radio=="option1"){  
				$scope.date_envoie.dt1=$scope.today.getTime()-604800000;  //3600*24*7*1000
			}
			if($scope.this_radio=="option2"){
				$scope.date_envoie.dt1=$scope.today.getTime()-2592000000;  //3600*24*30*1000
			}
			if($scope.this_radio=="option3"){
				$scope.date_envoie.dt1=$scope.today.getTime()-86400000;  //3600*24*1*1000
			}
			if($scope.this_radio=="option4"){
				var array_date=$('#datepicker-calendar').DatePickerGetDate();
				$scope.date_envoie.dt2= array_date[0][1].getTime();
				$scope.date_envoie.dt1= array_date[0][0].getTime();
			}
			$modalInstance.close($scope.date_envoie);
		};
		
		$scope.cancel = function() {
			$modalInstance.dismiss("cancel");
		};
    }
]);
