
var app=angular.module('comparatorAngularApp', ['ui.bootstrap', 'ngCookies','ngRoute','ngSanitize',"app.localization"]);

app.factory('_', function() {
	return window._; // assumes underscore has already been loaded on the page
});

app.controller("ArchiveCtrl",['$scope', '$cookieStore', '$rootScope','$http','$modal','$timeout','$sce', 'localize','_', function($scope, $cookieStore, $rootScope,$http, $modal,$timeout,$sce,localize, _) {
	
	$scope.user = $cookieStore.get('userID');
	$scope.compte = $cookieStore.get('compteID');
	$scope.supplier = $cookieStore.get("supplier");
	$scope.lang=$cookieStore.get('lang');
	$scope.check = false;
	
	
	localize.setLanguage($scope.lang);
	
	$http.jsonp('/user/sites?compte='+$scope.compte+'&callback=JSON_CALLBACK').success(function(data){
		$scope.sites = data;
	});

	$http.jsonp('/category?compte='+$scope.compte+'&callback=JSON_CALLBACK').success(function(data){
		$scope.categories = data;
		$scope.selectedCate= $scope.categories[0];
	}).error(function(data, status, headers, config) {
		console.log("errer");
	});

	var waitmodalInstance =$modal.open({
		templateUrl:"waitModal.html"
	});
	
	$http.jsonp('/articles/archive?compte=' + $scope.compte+'&callback=JSON_CALLBACK').success(function(data){     
		waitmodalInstance.close();
		$scope.articles = data;
		$scope.totalNumber=data.length;
	});

	$scope.openmodal = function(modal_id,data_trans,modaltype,index_i){
		
		var modalInstance =$modal.open({
			templateUrl: modal_id,
			controller:"ModalInstanceCtrl",
			resolve:{
				compte: function(){return $scope.compte},
				data: function(){return data_trans},
				modaltype:function(){return modaltype}
			}
		});

		modalInstance.result.then(function (data) {

			if(data.modaltype=="deleteArchiveBase"){
				$scope.articles.splice(index_i,1);
				$scope.totalNumber--;
				//$scope.initial_page($scope.totalNumber,$scope.currentPage);
				//$scope.nameFilter="";
				//$scope.categorieFilter = "Toutes les catégories";				
			}
			
		}, function () {
			console.log("finished modal");
		});

	};

	$scope.deleteArchive= function(currentArticle_id,index_i){
		var data_trans={"product_id":currentArticle_id};
		$scope.openmodal('deleteArticleModal.html',data_trans,'deleteArticleBase',index_i);
	}

	$scope.PercentageValue = function(articleBase){			
		
		if($scope.supplier==true)
			return 'PVTTC:'+articleBase.marge+"€ <br/>Remise :"+articleBase.percentage+"%<br/>Limite :"+((100 - articleBase.percentage)* articleBase.marge /100 )+"€";
		if($scope.supplier==false && articleBase.marge!="null"&& articleBase.marge!="undefined"&& articleBase.marge!="NaN")
			return $sce.trustAsHtml(articleBase.marge+'€'+'<br/> <span style="font-size:large; color: rgb(34,66,124)"> X'+parseFloat(articleBase.match[0].currentprice / articleBase.marge).toFixed(2)+"</span>");
	}


	$scope.loadChart =function(currentArticle){
		$scope.openmodal("graph.html",currentArticle,"Graph");
	}


}]);


function ModalInstanceCtrl ($scope, $modalInstance,$http, $modal, compte,data,modaltype) {

	$scope.compte=compte;
	$scope.data=data;
    $scope.rv=[];	

	if(modaltype=="deleteArticleBase"){
	  $scope.product_id=data.product_id;
	}

	if(modaltype=="Graph"){
		var param=$scope.data._id;
		$scope.articlename=$scope.data.name;
		$scope.frameUrl="views/modal/frame.html?compte="+$scope.compte+"&FA_id="+param+"&archive=true";
	}

	$scope.deleteThisArticle=function(){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
				
		$http.jsonp('/supprimer/archive?compte='+ $scope.compte+'&product_id='+$scope.product_id+'&callback=JSON_CALLBACK').success(function(data){
			waitmodalInstance.close();
			$scope.rv.modaltype="deleteArchiveBase";
			$modalInstance.close($scope.rv);

		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});	
	}

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
	};
  

};
