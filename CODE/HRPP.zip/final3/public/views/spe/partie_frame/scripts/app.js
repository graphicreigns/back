//'use strict';

var comparatorAngularApp = angular.module('comparatorAngularApp', ['ui.bootstrap', 'ngCookies','ngRoute','ngSanitize'])
    .config(['$routeProvider', function ($routeProvider) {
		
        $routeProvider
            .when('/', {
                templateUrl: 'views/login.html',
                controller: 'LoginCtrl'
            })
            /*.when('/validation', {
                templateUrl: 'views/validation.html',
                controller: 'ValidationCtrl'
            })*/
            .when('/reactivite', {
				templateUrl: 'views/reactivite.html',
                controller: 'ReactiviteCtrl'
            })           
            .when('/listing', {
                templateUrl: 'views/listing.html',
                controller: 'MainCtrl'
            })         
  /*           
             .when('/statistique', {
                templateUrl: 'views/statistique.html',
                controller: ''
            })    */                             
            .otherwise({
                redirectTo: '/'
            });
    }])
    .run(function ($rootScope, $cookieStore, $location) {
        $rootScope.$on("$routeChangeStart", function (event, next, current) {

            if (next.templateUrl != 'views/login.html' && $cookieStore.get('userID') == undefined) {
				
				if(parent==window){
					$location.path("/login");
				}
				else{
					console.log($rootScope);
				}
            }
            
        });
    });
