angular.module('comparatorAngularApp', ['ui.bootstrap', 'ngCookies','ngRoute','ngSanitize',"app.localization"]).factory('_', function() {
	return window._; // assumes underscore has already been loaded on the page
});

function MainCtrl ($scope, $cookieStore, $rootScope,$http, $modal,$timeout,$sce,localize,_) {

	$scope.user = $cookieStore.get('userID');
	$scope.compte = $cookieStore.get('compteID');
	$scope.supplier = $cookieStore.get("supplier");
	$scope.lang=$cookieStore.get('lang');

	localize.setLanguage($scope.lang);

	//value
	$scope.categorieFilter = "Toutes";
	$scope.select_def=true;
	$scope.nameFilter="";
	$scope.nameFocus=false;

	//attribut
	$scope.check = false;
	$scope.showthis=false; // stock ou modifier
	$scope.showrefresh=false;


//*************************************
//           modal function
//*************************************
	
    $scope.openmodal = function(modal_id,data_trans,modaltype,index_i,index_j){
		
		console.log("i"+index_i);
		console.log("j"+index_j);
		console.log(modaltype);
		var site_choisi="vide";
		if(index_j>=0)  site_choisi=$scope.sites[index_j].name;
		
		var modalInstance =$modal.open({
			templateUrl: modal_id,
			controller:"ModalInstanceCtrl",
			resolve:{
				categories: function(){return $scope.categories},
				sites: function(){return $scope.sites},
				site_choisi:function(){return site_choisi},
				compte: function(){return $scope.compte},
				supplier: function(){return $scope.supplier},
				data: function(){return data_trans},
				modaltype:function(){return modaltype}
			}
		});
		
		
		modalInstance.result.then(function (data) {
			if(data.modaltype=="newArticleBase"){
				var array_vide=[];
				array_vide.push(data.value);
				$scope.articles = array_vide;
				$scope.totalNumber++;

				$scope.currentPage=1;
				$scope.showNumber = 1;
				$scope.numPages=1;
				$scope.end=1;

				$scope.nameFilter=data.value.name;
				$scope.categorieFilter = "Toutes";
				$scope.select_def=true;

			}
			if(data.modaltype=="modifyArticleBase"){
				$scope.articles[index_i]['marge']=data.value.marge;
				$scope.articles[index_i]['percentage']=data.value.percentage;
				$scope.articles[index_i]['name']=data.value.name;
				$scope.articles[index_i].cat_name=data.value.cat_name;
				$scope.articles[index_i].img_url=data.value.img_url;
				$scope.articles[index_i].img_path=data.value.img_path;
			}
			if(data.modaltype=="addUrlBase"){
				$scope.articles[index_i].match[index_j]=data.value.v_article;
				/*if(data.value.img_path!="no_change"){
					$scope.articles[index_i].img_path=data.value.img_path;
					$scope.articles[index_i].img_url=data.value.img_url;
				}*/
			}
			if(data.modaltype=="modifyUrlBase"||data.modaltype=="deleteUrlBase"){
				$scope.articles[index_i].match[index_j]=data.value;
				/*if(data.value.img_path!="no_change"){
					$scope.articles[index_i].img_path=data.value.img_path;
					$scope.articles[index_i].img_url=data.value.img_url;
				}*/
			}
			/*if(data.modaltype=="deleteUrlBase"){
				$scope.articles[index_i].match[index_j].url=null;
				$scope.articles[index_i].match[index_j].currentprice=null;
				//$scope.articles[index_i].match[index_j].NV_cloche=null;
			}*/
			if(data.modaltype=="deleteArticleBase"){
				console.log(index_i);
				$scope.articles.splice(index_i,1);
				$scope.totalNumber--;
				$scope.initial_page($scope.totalNumber,$scope.currentPage);
				$scope.nameFilter="";
				$scope.categorieFilter = "Toutes";
				$scope.select_def=true;				
			}
		}, function () {
			console.log("finished modal");
		});
		
	};

	$scope.showhtml =function(content){		
		$scope.openmodal("stock.html",content,"",-1,-1);		
	}

	$scope.loadChart =function(currentArticle){
		$scope.openmodal("graph.html",currentArticle,"Graph",-1,-1);
	}

	$scope.openNewArticle =function(){		
		$scope.openmodal("newArticleModal.html","","newArticleBase",-1,-1);		
	}
	
	$scope.modifyArticle =function(currentArticle,index_i){
		var data_trans={"article":currentArticle};	
		$scope.openmodal('modifyArticleModal.html',data_trans,'modifyArticleBase',index_i,-1);	
	}
	
	$scope.addUrl = function(realArticle, currentArticle, index_i, index_j,that_td){
		
		var data_trans={"product_id":currentArticle._id, "site_id":realArticle.site, "currentname":currentArticle.name,"scope":that_td};
		$scope.openmodal("addUrlModal.html",data_trans,"addUrlBase",index_i,index_j);	
	}
	$scope.modifyUrl = function(realArticle, currentArticle, index_i, index_j,that_td){
		
		var data_trans={"article_id":realArticle._id, "product_id":currentArticle._id,"site_id":realArticle.site, "currentname":currentArticle.name,"url":realArticle.url,"price":realArticle.currentprice,"scope":that_td};
		$scope.openmodal("modifyUrlModal.html",data_trans,"modifyUrlBase",index_i,index_j);	
	}

	$scope.deleteUrl= function(currentArticle_id,realArticle,index_i,index_j){
		
		var data_trans={"product_id":currentArticle_id,"article_id":realArticle._id};
		$scope.openmodal('deleteUrlModal.html',data_trans,'deleteUrlBase',index_i,index_j);
	}
	
	$scope.deleteArticle= function(currentArticle_id,index_i){
		
		var data_trans={"product_id":currentArticle_id};
		$scope.openmodal('deleteArticleModal.html',data_trans,'deleteArticleBase',index_i,-1);
	}
	
	
	
//*************************************
//           pre-load function
//*************************************


	$http.jsonp('/user/sites?compte='+$scope.compte+'&callback=JSON_CALLBACK').success(function(data){
		$scope.sites = data;
	});
		
	
	$http.jsonp('/category?compte='+$scope.compte+'&callback=JSON_CALLBACK').success(function(data){
		$scope.categories = data;
		$scope.selectedCate= $scope.categories[0];
	}).error(function(data, status, headers, config) {
		//$scope.defaultValues();
		console.log("errer");
	});


	$scope.initial_page=function(nb,cur){
		
		$scope.currentPage=cur;
		$scope.showNumber = parseInt(nb);
		if(nb>1){
			$scope.numPages = parseInt(($scope.showNumber-1)/$scope.itemparPage)+1;
		}
		else
			$scope.numPages=1;
			
		if(nb<$scope.itemparPage){
			$scope.end=nb;
		}
		
	};


//*************************************
//        pagination function
//*************************************


	$scope.currentPage = 1;
	$scope.maxSize = 5;
	$scope.pagesdefault=5;
	$scope.num_selected=true;
	
	$scope.start=1;
	//$scope.end=$scope.itemparPage;

	$http.jsonp('/user/info?user='+$scope.user+'&callback=JSON_CALLBACK').success(function(data){
		$scope.itemparPage=parseInt(data.pages.listing);
		$scope.pagesdefault=parseInt(data.pages.listing);
		$scope.end=parseInt(data.pages.listing);
		
		$http.jsonp('/articles/number?compte=' + $scope.compte + '&callback=JSON_CALLBACK').success(function(nb){     
			$scope.totalNumber = nb;
			$scope.showNumber=nb;
			$scope.numPages = parseInt($scope.showNumber/$scope.itemparPage)+1;
			if(nb<$scope.itemparPage){
				$scope.end=nb;
			}
			$scope.pageChanged();
		});		
		
	});

	$scope.setPageDefault=function(){
		$http.jsonp('/user/pages_listing?user='+$scope.user+'&pages='+$scope.itemparPage+'&callback=JSON_CALLBACK').success(function(data){	
			alert("Pages default assigned to "+$scope.itemparPage);	
			$scope.pagesdefault=$scope.itemparPage;
		});
	};


	$scope.pageChanged = function() {
				
		var skipindex=($scope.currentPage-1)*$scope.itemparPage;
		$scope.start=($scope.currentPage-1)*$scope.itemparPage+1;
		
		if($scope.currentPage>=$scope.numPages)
			$scope.end=$scope.showNumber;
		else
			$scope.end=$scope.currentPage*$scope.itemparPage;


		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
		
		$http.jsonp('/articles?compte=' + $scope.compte + '&cat_id='+$scope.categorieFilter+'&mot_cle='+$scope.nameFilter+'&skipindex='+skipindex+'&nextindex='+$scope.itemparPage+'&callback=JSON_CALLBACK').success(function(data){
			//var sorted=_.toArray(_.indexBy(data, "name"));
			var sorted = _.sortBy(data, function (i) { return i.name.toLowerCase(); });
			waitmodalInstance.close();
			$scope.articles = sorted;
			window.scroll(0,0);
		});	
	};


//*************************************
//       filter
//*************************************

	$scope.categoriesFilterChange=function(){
		$http.jsonp('/filter/getcatnum?compte=' + $scope.compte + '&cat_id='+$scope.categorieFilter+'&callback=JSON_CALLBACK').success(function(nb){
	
			$scope.select_def=false;
			$scope.nameFilter="";		
			
			$scope.initial_page(nb,1);
			
			$scope.pageChanged();
			
		}); 
	};

   var filterTextTimeout;
    $scope.$watch('nameFilter', function (val) {
        if (filterTextTimeout) $timeout.cancel(filterTextTimeout);
        
        filterTextTimeout = $timeout(function() {
            if($scope.nameFilter==val&&$scope.nameFocus==true) {
				$scope.categorieFilter = "Toutes";	
				$scope.select_def=true;
					$http.jsonp('/filter/getnamenum?compte=' + $scope.compte + '&mot_cle='+val+'&callback=JSON_CALLBACK').success(function(nb){
									
						$scope.initial_page(nb,1);
						$scope.pageChanged();
						
					}); 
					
			}
        }, 1000); //delay 2s
    });


//*************************************
//        setcategory function
//*************************************
 	
	$scope.setCat = function(){
		
		var catmodalInstance =$modal.open({
			templateUrl:"setCategory.html",
			controller:"ModalInstanceCtrl2",
			resolve:{
				categories: function(){return $scope.categories},
				compte: function(){return $scope.compte}

			}			
		});
		
		
		catmodalInstance.result.then(function (data) {
			$scope.categories=data;
		}, function () {
			console.log("finished catmodal");
		});
		
	};
	

//*************************************
//        other function
//*************************************

	$scope.numItemChange = function(){
		//alert($scope.itemparPage);
		$scope.categorieFilter = "Toutes";
		$scope.select_def=true;
		$scope.nameFilter="";
		$scope.initial_page($scope.totalNumber,1);
		$scope.pageChanged();
		
	}

	$scope.PercentageValue = function(articleBase){			
		
		if($scope.supplier==true)
			return 'RRP : '+articleBase.marge+"€ <br/>Discount : "+articleBase.percentage+"%<br/>Limit : "+((100 - articleBase.percentage)* articleBase.marge /100 )+"€";
		if($scope.supplier==false && articleBase.marge!="null"&& articleBase.marge!="undefined"&& articleBase.marge!="NaN")
			return $sce.trustAsHtml(articleBase.marge+'€'+'<br/> <span style="font-size:large; color: rgb(34,66,124)"> X'+parseFloat(articleBase.match[0].currentprice / articleBase.marge).toFixed(2)+"</span>");
	}

	$scope.goToProductPage = function(article) {
		window.open(article.url);
	};

	
	$scope.getTip=function(this_objet){
		var date=new Date(this_objet.date_insert);
		var jours=this_objet.jours;
		return "Non vendu depuis le "+date.toLocaleDateString()+",<br>à vérifier dans "+jours+" jours!";
		
	};
	
	$scope.refresh_price= function(current,article,i,j){
		
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});

		$http.jsonp('/price/refresh?compte=' + $scope.compte + '&article_id='+article._id+'&product_id='+current._id+'&site_id='+article.site+'&url='+article.url+'&callback=JSON_CALLBACK').success(function(data){     
			waitmodalInstance.close();
			$scope.articles[i].match[j].currentprice=data.price;
			$scope.articles[i].match[j].stock=data.stock;
			$scope.articles[i].match[j].html=data.html;
			/*if(data.img_path!="no_change"){
				$scope.articles[i].img_path=data.img_path;
				$scope.articles[i].img_url=data.img_url;
			}*/
			
		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});
		
		/*$http.jsonp('/image?user=' + $scope.user + '&product_id='+current._id+'&callback=JSON_CALLBACK').success(function(data){     
			$scope.articles[i].img_url=data;
			
		}).error(function(data, status, headers, config) {
			alert("Eurreur");
		});*/
	};
		
};	

function ModalInstanceCtrl ($scope, $modalInstance, $http, $modal, categories,sites,site_choisi,compte,supplier,data,modaltype) {

  $scope.categories = categories;
  $scope.sites=sites;
  $scope.compte=compte;
  $scope.data=data;
  $scope.supplier=supplier;
  $scope.site_choisi=site_choisi;

  $scope.jours=30;

  $scope.rv=[];


  if(modaltype=="Graph"){
		var param=$scope.data._id;
		
		$scope.articlename=$scope.data.name;
		
		if($scope.supplier==true){
			var RRP=parseFloat($scope.data.marge)-(parseFloat($scope.data.marge)*parseFloat($scope.data.percentage)/100)
			$scope.frameUrl="views/modal/frame.html?compte="+$scope.compte+"&FA_id="+param+"&archive=false&RRP="+RRP;
		}
		else{
			$scope.frameUrl="views/modal/frame.html?compte="+$scope.compte+"&FA_id="+param+"&archive=false";			
		}		

  }


  if(modaltype=="modifyArticleBase")
  {
	$scope.name=data.article.name;
	$scope.marge=parseFloat(data.article.marge);
	$scope.percentage=parseFloat(data.article.percentage);
	$scope.selectedCate=data.article.cat_name;
	
	$scope.image_url=data.article.img_url;

  }

  if(modaltype=="addUrlBase")
  {
	$scope.product_id=data.product_id;
	$scope.site_id=data.site_id;
	$scope.currentname=data.currentname;
	$scope.that_td=data.scope;

  }
  
  if(modaltype=="modifyUrlBase")
  {
	$scope.article_id=data.article_id;
	$scope.product_id=data.product_id;
	$scope.site_id=data.site_id;
	$scope.currentname=data.currentname;
	$scope.price=data.price;
	$scope.thisurl=data.url;
	$scope.that_td=data.scope;
  }
  
  if(modaltype=="deleteUrlBase"){
	  $scope.article_id=data.article_id;
	  $scope.product_id=data.product_id;
  }
   if(modaltype=="deleteArticleBase"){
	  $scope.product_id=data.product_id;
  }

  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
  
  
	$scope.createArticleBase = function(url,site,name,cat,price,percentage){

		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
		
		
		$http.get('/articles/addArticleBase?url='+url+'&site='+site+'&price='+price+'&name='+name+'&compte='+$scope.compte+'&cat='+cat+'&percentage='+percentage).success(function(data){			
			
			$scope.rv.modaltype="newArticleBase";
			$scope.rv.value=data;
			waitmodalInstance.close();
			$modalInstance.close($scope.rv);

		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});
	};

  
	$scope.setArticleBase = function(name, cat,marge,percentage,image_url){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
		
		
		$http.get('/articles/setArticleBase?name='+name+'&compte='+$scope.compte+'&id='+$scope.data.article._id+'&cat='+cat+'&percentage='+percentage+'&marge='+marge+'&img_url='+image_url).success(function(data){			
			
			$scope.rv.modaltype="modifyArticleBase";
			$scope.rv.value=data;
			waitmodalInstance.close();
			$modalInstance.close($scope.rv);

		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});
		
	}
  
  
	$scope.addNewUrl = function(url){
	
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
		
		
		$http.jsonp('/price/addUrl?compte=' + $scope.compte + '&id='+$scope.product_id+'&site='+$scope.site_id+'&url='+url+'&callback=JSON_CALLBACK').success(function(data){     

			$scope.rv.modaltype="addUrlBase";
			$scope.rv.value=data;
			waitmodalInstance.close();
			$modalInstance.close($scope.rv);
			
		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});
		
	}
	
 	$scope.modifyThisUrl = function(url){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
		
		$http.jsonp('/price/modifyUrl?compte=' + $scope.compte + '&article_id='+$scope.article_id+'&product_id='+$scope.product_id+'&site='+$scope.site_id+'&url='+url+'&callback=JSON_CALLBACK').success(function(data){     
			waitmodalInstance.close();
			$scope.rv.modaltype="modifyUrlBase";
			$scope.rv.value=data;
			waitmodalInstance.close();
			$modalInstance.close($scope.rv);
			
		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});
		
	} 
  
	$scope.gererVendu = function(cloche,jours){		
		
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
		
		if(modaltype=="addUrlBase"){
			$http.jsonp('/price/nonVendu/addnew?compte=' + $scope.compte +'&cloche='+cloche+'&jours='+jours+'&id='+$scope.product_id+'&site='+$scope.site_id+'&callback=JSON_CALLBACK').success(function(data){     
				waitmodalInstance.close();
				$scope.rv.modaltype="addUrlBase";
				//adapt data type pour image;
				var adapt=[];
				adapt.v_article=data;
				//adapt.img_path="no_change";
				
				$scope.rv.value=adapt;
				waitmodalInstance.close();
				$modalInstance.close($scope.rv);
				
			}).error(function(data, status, headers, config) {
				alert("Erreur");
			});			
		}
		
		if(modaltype=="modifyUrlBase"){
			$http.jsonp('/price/nonVendu/modify?compte=' + $scope.compte +'&cloche='+cloche+'&jours='+jours+ '&id='+$scope.article_id+'&callback=JSON_CALLBACK').success(function(data){     
				waitmodalInstance.close();
				$scope.rv.modaltype="modifyUrlBase";
				$scope.rv.value=data;
				waitmodalInstance.close();
				$modalInstance.close($scope.rv);
				
			}).error(function(data, status, headers, config) {
				alert("Erreur");
			});				
		}
	}
  
	$scope.deleteThisUrl=function(){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
		
		$http.jsonp('/price/nonVendu/modify?compte=' + $scope.compte +'&cloche=false&jours=1&id='+$scope.article_id+'&callback=JSON_CALLBACK').success(function(data){
			waitmodalInstance.close();
			$scope.rv.modaltype="deleteUrlBase";
			$scope.rv.value=data;
			$modalInstance.close($scope.rv);
		
		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});	
	}
	
	$scope.deleteThisArticle=function(){
		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});
				
		$http.jsonp('/supprimer/article?compte='+ $scope.compte+'&product_id='+$scope.product_id+'&callback=JSON_CALLBACK').success(function(data){
			waitmodalInstance.close();
			$scope.rv.modaltype="deleteArticleBase";
			$modalInstance.close($scope.rv);
		
		}).error(function(data, status, headers, config) {
			alert("Erreur");
		});	
	}

};

function ModalInstanceCtrl2 ($scope, $modalInstance, $http, categories,compte) {
	$scope.categories = categories;
	$scope.compte=compte;

	$scope.formAddText="";

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
	}
	
	
	$scope.categoryClearSelected = function(){

		$scope.categories.forEach(function(element){

			if(element.deleted==true){
				$http.jsonp('/category/deletecatgen?compte='+$scope.compte+'&text_id='+element._id+'&callback=JSON_CALLBACK').success(function(data){	  
					alert("deleted "+element.name);
				});	
			}
		});	
		  
		$scope.categories = $scope.categories.filter( function(eachone){
			return !eachone.deleted;
		})
	};

	$scope.addToCategory = function(formAddText){
		if(formAddText=="")
		{
			alert("Entree null !!");
		}
		else if(formAddText.indexOf("&")>0)
		{
			alert("Les catégories ne peuvent pas comporter '&' !");
		}
		else{		
			$http.jsonp('/category/addcatgen?compte='+$scope.compte+'&text='+formAddText+'&callback=JSON_CALLBACK').success(function(data){	  
			  
				$scope.categories.push({_id:data._id, name:formAddText, deleted:false});
			 });
		}
	};
	
	$scope.update =function(){
		$modalInstance.close($scope.categories);
	};

};
