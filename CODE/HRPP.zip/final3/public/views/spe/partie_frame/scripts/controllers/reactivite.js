angular.module('comparatorAngularApp', ['ui.bootstrap', 'ngCookies','ngRoute','ngSanitize',"app.localization"]);

function ReactiviteCtrl($scope, $cookieStore, $rootScope, $http, $modal, $timeout,$sce,localize) {

	$scope.user = $cookieStore.get('userID');
	$scope.compte = $cookieStore.get('compteID');
	$scope.supplier= $cookieStore.get('supplier');
	$scope.lang=$cookieStore.get('lang');

	localize.setLanguage($scope.lang);
	
	$scope.url_img='';


	//value
	$scope.categorieFilter = 'Toutes';

	$scope.nameFilter="";
	$scope.nameFocus=false;
	
	$scope.dt2=new Date();
	$scope.dt1=new Date($scope.dt2.getTime()-86400000);
	

	//attribut
	$scope.check = false;
	$scope.showstock=false;

	//all the modal
	$scope.waitModalOpened=false;
    
//*************************************
//       pre-load function
//*************************************

	$http.jsonp('/user/sites?compte='+$scope.compte+'&callback=JSON_CALLBACK').success(function(data){
		$scope.sites = data;
	});  
	
	$http.jsonp('/category?compte='+$scope.compte+'&callback=JSON_CALLBACK').success(function(data){
		$scope.categories = data;
	}).error(function(data, status, headers, config) {
		$scope.defaultValues();
	});  
	
	 
//*************************************
//       react function
//*************************************

	$scope.search = function(first_time){

		var skipindex=($scope.currentPage-1)*$scope.itemparPage;

		var waitmodalInstance =$modal.open({
			templateUrl:"waitModal.html"
		});

		if($scope.supplier==false){
			
			$http.jsonp('/react/retailer?compte=' + $scope.compte +'&date_start='+$scope.dt1.getTime()+'&date_end='+$scope.dt2.getTime()+'&cat_id='+$scope.categorieFilter+'&mot_cle='+$scope.nameFilter+'&skipindex='+skipindex+'&nextindex='+$scope.itemparPage+'&callback=JSON_CALLBACK').success(function(data){     
				waitmodalInstance.close();
				if(first_time==true){
					$scope.totalNumber=data.num;
				}
				
				$scope.showNumber=data.num;
				$scope.numPages = parseInt($scope.showNumber/$scope.itemparPage)+1;
				
				$scope.start=($scope.currentPage-1)*$scope.itemparPage+1;
				if($scope.currentPage>=$scope.numPages)
					$scope.end=$scope.showNumber;
				else
					$scope.end=$scope.currentPage*$scope.itemparPage;
				
				$scope.articles = data.data;
			});
		}
		else{
			
			$http.jsonp('/react/supplier?compte=' + $scope.compte +'&cat_id='+$scope.categorieFilter+'&mot_cle='+$scope.nameFilter+'&skipindex='+skipindex+'&nextindex='+$scope.itemparPage+'&callback=JSON_CALLBACK').success(function(data){     
				waitmodalInstance.close();
				
				if(first_time==true){
					$scope.totalNumber=data.num;
				}
				
				$scope.showNumber=data.num;
				$scope.numPages = parseInt($scope.showNumber/$scope.itemparPage)+1;
				
				$scope.start=($scope.currentPage-1)*$scope.itemparPage+1;
				if($scope.currentPage>=$scope.numPages)
					$scope.end=$scope.showNumber;
				else
					$scope.end=$scope.currentPage*$scope.itemparPage;
				
				$scope.articles = data.data;
			});	
		}
	}

//*************************************
//        pagination function
//*************************************
	$scope.currentPage = 1;
	$scope.maxSize = 5;
	$scope.pagesdefault=5;
	$scope.num_selected=true;
	
	$scope.start=1;
	//$scope.end=$scope.itemparPage;

	$scope.pageChanged = function() {		
		$scope.search(false);			
	};

    var filterTextTimeout;
    $scope.$watch('nameFilter', function (val) {
        if (filterTextTimeout) $timeout.cancel(filterTextTimeout);
        
        
        filterTextTimeout = $timeout(function() {
            if($scope.nameFilter==val&&$scope.nameFocus==true) {
				$scope.currentPage = 1;
				$scope.search(false);
			}
        }, 1000); // delay 250 ms*/
    });
    	
	$scope.categoriesFilterChange=function(){
		$scope.currentPage = 1;
		$scope.search(false);
	};
	
	$scope.setPageDefault=function(){
		$http.jsonp('/user/pages_reactivity?user='+$scope.user+'&pages='+$scope.itemparPage+'&callback=JSON_CALLBACK').success(function(data){	
			alert("Pages default assigned to "+$scope.itemparPage);	
			$scope.pagesdefault=$scope.itemparPage;
		});
	};


	$http.jsonp('/user/info?user='+$scope.user+'&callback=JSON_CALLBACK').success(function(data){

		$scope.itemparPage=parseInt(data.pages.reactivity);
		$scope.pagesdefault=parseInt(data.pages.reactivity);
		$scope.end=parseInt(data.pages.reactivity);
		
		$scope.search(true);			
		
	});
	

	//$('.table-fixed-header').fixedHeader();

//*************************************
//       date picker
//*************************************

    $scope.change_date=function(){
		console.log("fuck");
		var array_date=$('#datepicker-calendar').DatePickerGetDate();
		console.log(array_date);
	};
    
//*************************************
//           modal function
//*************************************
	
    $scope.openmodal = function(modal_id,data_trans,modaltype,index_i,index_j){
		
		console.log("i"+index_i);
		console.log("j"+index_j);
		
		var modalInstance =$modal.open({
			templateUrl: modal_id,
			controller:"ModalInstanceCtrl",
			resolve:{
				categories: function(){return $scope.categories},
				sites: function(){return $scope.sites},
				compte: function(){return $scope.compte},
				supplier: function(){return $scope.supplier},
				data: function(){return data_trans},
				modaltype:function(){return modaltype}
			}
		});
	};

	$scope.loadChart =function(currentArticle){
		$scope.openmodal("graph.html",currentArticle,"Graph",-1,-1);
	}

	$scope.showhtml =function(content){		
		$scope.openmodal("stock.html",content,"",-1,-1);		
	}

//*************************************
//        other function
//*************************************
	$scope.PercentageValue = function(articleBase){

		if($scope.supplier==true)
			return "RRP : "+articleBase.marge+"€ <br/>Discount : "+articleBase.percentage+"%<br/>Limit : "+((100 - articleBase.percentage)* articleBase.marge /100 )+"€";
		if($scope.supplier==false && articleBase.marge!="null" && articleBase.marge!="undefined"&& articleBase.marge!="NaN")			
			return $sce.trustAsHtml(articleBase.marge+'€'+'<br/> <span style="font-size:large; color: rgb(34,66,124)"> X'+parseFloat(articleBase.match[0].currentprice / articleBase.marge).toFixed(2)+"</span>");
	}

	$scope.goToProductPage = function(article) {
		window.open(article.url);
	};  
	
	$scope.numItemChange = function(){
		$scope.currentPage = 1;
		$scope.search(false);		
	}

};


function ModalInstanceCtrl ($scope, $modalInstance, $http, $modal, categories,sites,compte,supplier,data,modaltype) {

  $scope.sites=sites;
  $scope.compte=compte;
  $scope.data=data;
  $scope.supplier=supplier;

  if(modaltype=="Graph"){
		var param=$scope.data._id;
		$scope.articlename=$scope.data.name;
		
		
		if($scope.supplier==true){
			var RRP=parseFloat($scope.data.marge)-(parseFloat($scope.data.marge)*parseFloat($scope.data.percentage)/100)
			$scope.frameUrl="views/modal/frame.html?compte="+$scope.compte+"&FA_id="+param+"&archive=false&RRP="+RRP;
		}
		else{
			$scope.frameUrl="views/modal/frame.html?compte="+$scope.compte+"&FA_id="+param+"&archive=false";			
		}		
		
  }


  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
  
  


};

