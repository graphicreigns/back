APP.controller('PerfCtrl', ['$scope', '$location', '$cookieStore', '$http','$modal','localize',
function ($scope, $location, $cookieStore, $http, $modal, localize) {

  $scope.title="Veille Concurentielle";
  $scope.AddSellQuantity="";
  $scope.sites=[]; 
  $scope.datas=[];
  $scope.user = $cookieStore.get('compteID');
  $scope.dtfin= new Date();
  $scope.dtdebut= new Date($scope.dtfin.getTime()-(7*30*24*60*60*1000));
  $scope.dtc = new Date(); 
  $scope.AllSiteOptions=[];
  $scope.lesseries = [];
  $scope.commentaires=[]; 
  $scope.dateOptions = {
    'year-format': "'yy'",
    'starting-day': 1
  };
  $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'shortDate'];
  $scope.showWeeks = true;


/*
 *   fonctions pour désigner le graphique
 * 
 * */

  $scope.draw=function(donnes,lesseries){

	$scope.lesseries = lesseries;
	  $scope.options={
		  lineMode: "cardinal",
		  tension: 0.7,
		  axes: {x: {key: "date", type: "date", ticks:9} }, 
		  //y: {key: "y",type: "linear"}},
		  tooltipMode: "dots",
		  stacks: [],
		  columnsHGap: 5,
		  series: lesseries,
		  tooltip: 
			{
			   mode: "scrubber", 
			   formatter: function(x, y, series) {
				  // on affiche la date format JJ/MM,AAAA   
				  var affiche_y= y;
				  //console.log(affiche_y);  
				  var affiche_x=new Date(x); 
				  var retour = affiche_x.getDate()+"/"+(affiche_x.getMonth()+1)+"/";
				  retour += affiche_x.getFullYear() + " :" + affiche_y;

				  return retour;
			   }
			 }                 
	  };

	  $scope.datas=donnes;
  }

  $scope.filterSiteOptions=function(data){
	  
		  var serielength = $scope.AllSiteOptions.length;
		  
		  var lesseries = [];
		  var datalength = data.length;

		  var hasFound = false;
		  for(var i=0; i<serielength;++i){//for each serie
			  var serie = $scope.AllSiteOptions[i];
			  hasFound = false;
			  for(var j=0; j<datalength && !hasFound; ++j){
				  //var mydata = $scope.datas[j];
				  var mydata=data[j];
				  var datakeys = Object.keys(mydata);
				  if(_.contains(datakeys, serie.y)){
					  hasFound = true;
					  lesseries.push(serie);
				  }
			  }
		  }
		 
		  $scope.draw(data.reverse(),lesseries.reverse());
  
	  
  }


  $scope.checkdate = function(){
   
      $http.post('/perf/getstat_command',{"compte":$scope.user, "debut":$scope.dtdebut.getTime(), "fin":$scope.dtfin.getTime()}).success(function(data){
                 
          _.map(data,function(obj){ obj.date = new Date(obj.date);  });

          //$scope.datas=$scope.datatest;
         // $scope.datas=data.reverse();//On reverse pour trier par date,du plus ancien au plus recent
			//console.log(data);

			$scope.filterSiteOptions(data);
      }); 
  };


/*
 *  Fonctions  A faire
 * 
 * */
   

  $scope.checkdatecomment = function(){
    $http.post('/perf/getcommentaire',{"date":$scope.dtc.getTime(), "compte":$scope.user}).success(function(data){
      _.map(data,function(obj){ 
        obj.date_debut = new Date(obj.date_debut),
        obj.date_fin = new Date(obj.date_fin); 
      });
      $scope.commentaires=data;
   // console.log($scope.commentaires);
    });
  };      
  
  $scope.AddToData = function(){
    $http.post('/perf/putstat_command',{"nb":$scope.NumberOfOrders,"date":$scope.dt.getTime(),"id_site": $scope.SiteSelect}).success(function(data){
      //$scope.checkdate();
      console.log("ok");
    });
  };  

  $scope.AddToComment = function() {
    $http.post('/perf/putcommentaire',{"debut":$scope.dtdebutc.getTime(),"fin":$scope.dtfinc.getTime(), "compte":$scope.UserSelect, "contenu":$scope.Commentaire});
  }

/*
 *   fonctions pour choisir le date
 * 
 * */  

  $scope.today = function() {
    return $scope.dt = new Date();
  };
  
  $scope.toggleWeeks = function() {
    return $scope.showWeeks = !$scope.showWeeks;
  };
      
  $scope.clear = function() {
    return $scope.dt = null;
  };
      
  $scope.disabled = function(date, mode) {
    return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
  };
      
  $scope.toggleMin = function() {
    var _ref;
    return $scope.minDate = ( ((_ref = $scope.minDate) != null) ? _ref : {  "null": new Date() } );
  };
     
  $scope.open1 = function($event) {
    $event.preventDefault();
    $event.stopPropagation();
    return $scope.opened1 = true;
  };

  $scope.open2 = function($event) {
    $event.preventDefault();
    $event.stopPropagation();
    return $scope.opened2 = true;
  };

  $scope.open3 = function($event) {
    $event.preventDefault();
    $event.stopPropagation();
    return $scope.opened3 = true;
  };

  $scope.open4 = function($event) {
    $event.preventDefault();
    $event.stopPropagation();
    return $scope.opened4 = true;
  };

  $scope.open5 = function($event) {
    $event.preventDefault();
    $event.stopPropagation();
    return $scope.opened5 = true;
  };

  $scope.open6 = function($event) {
    $event.preventDefault();
    $event.stopPropagation();
    return $scope.opened6 = true;
  };




/*
 *   pre-load functions
 * 
 * */  

	$http.post('/perf/getsiteOptions',{"compte":$scope.user}).success(function(data){
		_.map(data,function(obj){   

		  obj.type = "line",
		  obj.thickness= "5px",
		  obj.dotSize= 2,
		  obj.drawDots= true,     
		  obj.visible = true,
		  obj.axis = "y";  

		});		
		$scope.AllSiteOptions=data;
			  
	});	

	$scope.today();
	$scope.toggleMin();
	$scope.checkdatecomment();    
	$scope.checkdate();

}]);
